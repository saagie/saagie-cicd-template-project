from hdfs import InsecureClient
import os
import pytz
import traceback
import pandas as pd
import sys
from datetime import datetime
import ibis

sys.path.insert(0, "../")
try:
    import utils
except:
    import pri.utils as utils


class PriErrorException(Exception):
    def __init__(self, msg):
        super().__init__(msg)


"""
TODO: Améliorer la gestion des sites multifichiers (VSB)
"""

try:
    try:
        client_hdfs = utils.return_client_hdfs(os.environ['USER_PRI_INVALIDATE'])

        url_hdfs = utils.get_url_active_namenode(os.environ['USER_PRI_INVALIDATE'])

        ibis_hdfs = ibis.hdfs_connect(host=url_hdfs, port=int(os.environ['PORT_HDFS']))
        url_hdfs = url_hdfs.split(':')[0] + url_hdfs.split(':')[1]
        ibis_client = ibis.impala.connect(host=os.environ['IP_IMPALA'], port=int(os.environ['PORT_IMPALA']),
                                          hdfs_client=ibis_hdfs, user=os.environ['USER_PRI_INVALIDATE'],
                                          password=os.environ['USER_PRI_INVALIDATE_PWD'],
                                          auth_mechanism='PLAIN', database=os.environ['IMPALA_BDD_PRI'],
                                          use_ssl=bool(os.environ['IMPALA_SSL_ACTIVATED'] == "1"))

        path_hdfs_error_flag_file = sys.argv[1]
        path_hdfs_impala_table_check_data_source = sys.argv[2]
        impala_table_flow = sys.argv[3]
        impala_table_inventory = sys.argv[4]
        impala_table_inventory_controlling = sys.argv[5]
        list_elements = client_hdfs.list(path_hdfs_error_flag_file, status=True)
        flag_file_error_present = False
        df_sites_error = pd.DataFrame()

        raise_error = False
        list_site = ['Controlling', 'Mulheim & Rath plug', 'Tianda', 'VOGFR',
                     'VSB_Data - Billet, Semi Finished, Finished',
                     'VSB_Data - Scrap, Raw Material', 'VSB', 'VSTAR']
        list_step = ['import', 'inventory', 'flow']

        df_mapping_error_template = utils.query_impala(ibis_client, 'select * from pri.m_error_file_source_file')
        df_check_data_source = utils.query_impala(ibis_client, 'select * from pri.check_data_source_template').rename(
            columns={'scrap': '1 - Scrap',
                     'other_rm': '2 - Other RM',
                     'billet': '3 - Billet',
                     'strategic_billet': '3.1 - Strategic Billet',
                     'wip': '4 - WIP',
                     'strategic_wip': '4.1 - Strategic WIP',
                     'finished_goods': '5 - Finished goods',
                     'strategic_fg': '5.1 - Strategic FG'
                     })
        df_inventory_template = utils.query_impala(ibis_client, 'select * from pri.inventory_template')
        df_flow_template = utils.query_impala(ibis_client, 'select * from pri.flow_template')
        df_inventory = utils.query_impala(ibis_client, 'select * from pri.' + impala_table_inventory)
        df_flow = utils.query_impala(ibis_client, 'select * from pri.' + impala_table_flow)
        df_inventory_controlling_template = utils.query_impala(ibis_client,
                                                               'select * from pri.inventory_controlling_template')
        df_inventory_controlling = utils.query_impala(ibis_client,
                                                      'select * from pri.' + impala_table_inventory_controlling)
        df_sprint_dates = utils.get_sprint_dates()
        # sprint_date_now = df_sprint_dates[df_sprint_dates['period'] == 'Jun 19']['sprint_date'].iloc[0]
        # datetime.now().replace(month=now.month - 1).strftime('%d/%m/%Y')
        if datetime.now().month == 1:
            dateTimeNow = datetime.now().replace(month=12).replace(year=datetime.now().year - 1).strftime('%b %y')
        else:
            dateTimeNow = datetime.now().replace(month=datetime.now().month - 1).strftime('%b %y')

        sprint_date_now = df_sprint_dates[df_sprint_dates['period'] == dateTimeNow]['sprint_date'].iloc[0]

        for file in list_elements:
            if file[1]['type'] == 'FILE':
                print("Detected files :" + file[0])
                # flag that files are present to raise an error
                flag_file_error_present = True
                try:
                    # detect sites and files that are in error
                    match_site = [x for x in list_site if x in file[0]][0]
                    match_step = [x for x in list_step if x in file[0]][0].capitalize()
                except:
                    print("error identifying site and step on the file: " + str(
                        file[0]) + '\n' + traceback.format_exc())
                df_sites_error = df_sites_error.append(
                    pd.DataFrame([[match_site, match_step]], columns=['error_site', 'error_data_type']))
                # log the error files
                path_log_errors = path_hdfs_error_flag_file + '/' + datetime.now().strftime('%d%m%Y')
                client_hdfs.makedirs(path_log_errors, permission=770)
                client_hdfs.delete(path_log_errors + '/' + file[0])
                name_file_cible = datetime.now(pytz.timezone('Europe/Paris')).strftime('%H_%M_%S') + '_' + file[0]
                client_hdfs.rename(path_hdfs_error_flag_file + '/' + file[0], path_log_errors + '/' + name_file_cible)

        if not df_sites_error.empty:
            # Detect files and sites in error
            df_sites_error = df_sites_error.reset_index(drop=True)
            df_sites_error = \
            df_sites_error.merge(right=df_mapping_error_template, how='left', on=['error_site', 'error_data_type']) \
                [['table_file', 'table_site', 'table_data_type']]

            df_sites_error = df_sites_error[
                ['table_file', 'table_site', 'table_data_type']].drop_duplicates().reset_index(drop=True)

            df_check_data_source = df_check_data_source.merge(right=df_sites_error, how='left',
                                                              left_on=['file', 'site', 'data_type'],
                                                              right_on=['table_file', 'table_site', 'table_data_type'])


            def fill_error_file(row, columns):
                # si la valeur = NaN c'est que la jointure n'a pas pu se faire et qu'il n'y apas eu d'erreur
                if row['table_file'] == row['table_file']:
                    # s'il y a eu une erreur il faut remplacer 2 par -1
                    for col in columns:
                        if row[col] == '2':
                            row[col] = -1
                return row


            df_check_data_source = df_check_data_source.apply(
                lambda row: fill_error_file(row, list(df_check_data_source.columns)), axis=1)
            df_check_data_source = df_check_data_source.drop(columns=['table_file', 'table_site', 'table_data_type'])
        # Detect flow data missing
        df_flow['flow_next_month'] = df_flow['flow_next_month'].replace('', 0).astype(float)
        df_flow = df_flow[df_flow['flow_next_month'] > 0]
        df_flow = df_flow[df_flow['sprint_date'] == sprint_date_now][['sprint_date', 'company', 'product_type']]
        df_flow_template = df_flow_template[['sprint_date', 'company', 'product_type']]
        df_flow_template['sprint_date'] = sprint_date_now
        df_flow_missing = pd.concat([df_flow_template, df_flow]).drop_duplicates(keep=False)

        for index, row in df_flow_missing.iterrows():
            value_cell = df_check_data_source[(df_check_data_source['site'] == row['company']) \
                                              & (df_check_data_source['data_type'] == 'Flow')][row['product_type']] \
                .replace('', 0).astype(int).max()
            if value_cell == 2:
                df_check_data_source[row['product_type']] = df_check_data_source[row['product_type']] \
                    .mask((df_check_data_source['site'] == row['company']) \
                          & (df_check_data_source['data_type'] == 'Flow'), 0)
                df_check_data_source['updated'] = df_check_data_source['updated'] \
                    .mask((df_check_data_source['site'] == row['company']) \
                          & (df_check_data_source['data_type'] == 'Flow'), 0)

        # Detect inventory data missing
        df_inventory_template = df_inventory_template[['sprint_date', 'company', 'product_type']]
        df_inventory_template['sprint_date'] = sprint_date_now
        df_inventory['qty'] = df_inventory['qty'].replace('', 0).astype(float)
        df_inventory['amount'] = df_inventory['amount'].replace('', 0).astype(float)
        df_inventory = df_inventory[(df_inventory['qty'] > 0) | (df_inventory['amount'] > 0)]
        df_inventory = df_inventory[df_inventory['sprint_date'] == sprint_date_now][
            ['sprint_date', 'company', 'product_type']]
        df_inventory_missing = pd.concat([df_inventory_template, df_inventory]).drop_duplicates(keep=False)

        for index, row in df_inventory_missing.iterrows():
            value_cell = df_check_data_source[(df_check_data_source['site'] == row['company']) \
                                              & (df_check_data_source['data_type'] == 'Inventory')][row['product_type']] \
                .replace('', 0).astype(int).max()
            if value_cell == 2:
                df_check_data_source[row['product_type']] = df_check_data_source[row['product_type']] \
                    .mask((df_check_data_source['site'] == row['company']) \
                          & (df_check_data_source['data_type'] == 'Inventory'), 0)
                df_check_data_source['updated'] = df_check_data_source['updated'] \
                    .mask((df_check_data_source['site'] == row['company']) \
                          & (df_check_data_source['data_type'] == 'Inventory'), 0)

        # Checking inventory controlling data
        df_inventory_controlling_template = df_inventory_controlling_template[['sprint_date', 'site']]
        df_inventory_controlling_template['sprint_date'] = sprint_date_now
        df_inventory_controlling['amount'] = df_inventory_controlling['amount'].replace('', 0).astype(float)
        df_inventory_controlling = df_inventory_controlling[df_inventory_controlling['amount'] > 0]
        df_inventory_controlling = df_inventory_controlling[df_inventory_controlling['sprint_date'] == sprint_date_now][
            ['sprint_date', 'site']]
        df_inventory_controlling_missing = pd.concat(
            [df_inventory_controlling_template, df_inventory_controlling]).drop_duplicates(keep=False)

        for index, row in df_inventory_controlling_missing.iterrows():
            value_cell = df_check_data_source[(df_check_data_source['site'] == 'Corporate') \
                                              & (df_check_data_source['data_type'] == 'Inventory')][
                row['site'].lower().replace(' ', '_')] \
                .replace('', 0).astype(int).iloc[0]
            if value_cell == 2:
                df_check_data_source[row['site'].lower().replace(' ', '_')] = df_check_data_source[
                    row['site'].lower().replace(' ', '_')] \
                    .mask((df_check_data_source['site'] == 'Corporate') \
                          & (df_check_data_source['data_type'] == 'Inventory'), 0)

                df_check_data_source['updated'] = df_check_data_source['updated'] \
                    .mask((df_check_data_source['site'] == 'Corporate') \
                          & (df_check_data_source['data_type'] == 'Inventory'), 0)


        # Set all others to 1. If the number in df_check_data_source is still '2' it means it wasn't in error or missing
        def fill_data_correct(row, columns):
            for col in columns:
                if row[col] == '2':
                    row[col] = 1
            return row


        df_check_data_source = df_check_data_source.apply(
            lambda row: fill_data_correct(row, df_check_data_source.columns), axis=1)
        # df_check_data_source.to_csv('df_check_data_source.csv', sep=';', index=False, header=False)
        # client_hdfs.upload('/pri/check_data_source/', 'df_check_data_source.csv', overwrite=True)
        df_check_data_source['check_date'] = datetime.now().strftime('%d/%m/%Y')

        # Check VSB
        # Check VSB Flow
        sum_vsb_flow = int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                (df_check_data_source['data_type'] == 'Flow')]['3 - Billet'].iloc[0]) + \
                       int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                (df_check_data_source['data_type'] == 'Flow')]['4 - WIP'].iloc[0]) + \
                       int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                (df_check_data_source['data_type'] == 'Flow')][
                               '5 - Finished goods'].iloc[0])
        print('sum_vsb_flow = ' + str(sum_vsb_flow))
        if sum_vsb_flow >= 3:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Flow'), '1')
        elif sum_vsb_flow < 0:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Flow'), '-1')
        else:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Flow'), '0')
        ###

        sum_vsb_flow_rm = int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                   (df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                                                   (df_check_data_source['data_type'] == 'Flow')]['2 - Other RM'].iloc[
                                  0]) + \
                          int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                   (df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                                                   (df_check_data_source['data_type'] == 'Flow')]['1 - Scrap'].iloc[0])
        print('sum_vsb_flow_rm = ' + str(sum_vsb_flow))
        if sum_vsb_flow_rm >= 2:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Flow'), '1')
        elif sum_vsb_flow_rm < 0:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Flow'), '-1')
        else:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Flow'), '0')

        # Check VSB Inventory
        sum_vsb_inventory = int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                     (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                     (df_check_data_source['data_type'] == 'Inventory')][
                                    '3 - Billet'].iloc[0]) + \
                            int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                     (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                     (df_check_data_source['data_type'] == 'Inventory')][
                                    '4 - WIP'].iloc[0]) + \
                            int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                     (df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                                                     (df_check_data_source['data_type'] == 'Inventory')][
                                    '5 - Finished goods'].iloc[0])
        print('sum_vsb_inventory = ' + str(sum_vsb_flow))
        if sum_vsb_inventory >= 3:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '1')
        elif sum_vsb_inventory < 0:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '-1')
        else:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'Monthly Dynamic VSM file') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '0')

        ####
        sum_vsb_inventory_rm = int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                        (df_check_data_source[
                                                             'file'] == 'VSB raw material stock & flow') & \
                                                        (df_check_data_source['data_type'] == 'Inventory')][
                                       '2 - Other RM'].iloc[0]) + \
                               int(df_check_data_source[(df_check_data_source['site'] == 'VSB') & \
                                                        (df_check_data_source[
                                                             'file'] == 'VSB raw material stock & flow') & \
                                                        (df_check_data_source['data_type'] == 'Inventory')][
                                       '1 - Scrap'].iloc[0])
        print('sum_vsb_inventory_rm = ' + str(sum_vsb_flow))
        if sum_vsb_inventory_rm >= 2:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '1')
        elif sum_vsb_inventory_rm < 0:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '-1')
        else:
            df_check_data_source['updated'] = df_check_data_source['updated'] \
                .mask((df_check_data_source['file'] == 'VSB raw material stock & flow') & \
                      (df_check_data_source['data_type'] == 'Inventory'), '0')

        utils.push_file_hdfs(df=df_check_data_source, file_path=path_hdfs_impala_table_check_data_source,
                             v_client_hdfs=client_hdfs)
        try:
            print("Invalidate Impala Metadata")
            utils.invalidate_impala_metadata()
        except:
            print('Error Invalidate Impala Metadata.' + '\n' + traceback.format_exc())
    except:
        print("An error occured while analyzing if data in Excel is updated." + '\n' + traceback.format_exc())
        raise_error = True

    if flag_file_error_present:
        raise PriErrorException(
            'PRI - An error occured during the PRI pipeline, check error files in: ' + path_hdfs_error_flag_file + '/' + name_file_cible)
    else:
        print(
                    'PRI - Everything went fine in the PRI pipeline. There is no error file in: ' + path_hdfs_error_flag_file + '/')

    if raise_error:
        raise NameError('An error occured while analyzing if data in Excel is updated')
except PriErrorException:
    raise PriErrorException(
        'PRI - An error occured during the PRI pipeline, check error files in: ' + path_hdfs_error_flag_file + '/nom_fichier')
except:
    raise NameError(
        'PRI - Unknow error occured while checking error flag files in: ' + path_hdfs_error_flag_file + '/nom_fichier' + '\n' + \
        'Please check in: ' + path_hdfs_error_flag_file + '. If there is an error file check it and try solve the error.')
