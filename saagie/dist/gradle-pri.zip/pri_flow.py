import pandas as pd
from hdfs import InsecureClient
import os
import sys
from datetime import datetime
import traceback
import numpy as np
import logging

try:
    import utils as utils
except:
    import pri.utils as utils


# TODO factoriser les fonctions de traitement dans un fchier séparer


def treat_vogfr_excel_file(excel_file_path):
    # read_file
    df = pd.read_excel(excel_file_path, sheet_name='WW_Flow')

    # Garder que les colonnes utiles
    list_column = [column for column in df.columns if not 'Unnamed' in str(column)]
    df = df[list_column]

    # get sprint dates
    df_sprint_dates = utils.get_sprint_dates()

    # transform dates to the correct format for joining mm/yyyy
    df['Period_tmp'] = df['Period'].apply(
        lambda x: datetime.strptime(utils.format_date_for_join(x), "%d/%m/%Y").strftime("%m/%Y"))

    # format dates in the sprint date table to join on mm/yyyy format
    df_sprint_dates['Period_tmp'] = df_sprint_dates['sprint_date'].apply(
        lambda x: datetime.strptime(x, "%d/%m/%Y").strftime("%m/%Y"))

    # Join dataframe
    df = df.merge(right=df_sprint_dates, how='left', on='Period_tmp')

    # filter rows in 2018
    # df = df[df['Period'] > '2018-12-31'].reset_index(drop=True)
    #
    df = df[['period', 'sprint_date', 'Company', 'Product Type', 'Flow (T)']]

    return df


def treat_tianda_excel_file(excel_file_path):
    # Lire le fichier excel
    df_tianda_flow = pd.read_excel(excel_file_path, sheet_name=0, skiprows=1, header=None) \
        .rename(columns={0: 'Period', 1: 'Company', 2: 'Product_Type', 3: 'Flow_next_month'})

    df_tianda_flow = df_tianda_flow[~df_tianda_flow['Flow_next_month'].isnull()]

    return utils.clean_add_sprint_dates(df_tianda_flow)


def treat_vstar_excel_file(excel_file_path):
    # Lire le fichier excel pour extraire les dates
    df_date = pd.read_excel(excel_file_path, sheet_name=0, skiprows=0)[0:2].reset_index(drop=True)
    df_date = df_date.drop(columns=[df_date.columns[0], df_date.columns[1]])  # .drop(columns=[0, 1])

    df_date = df_date.T.reset_index(drop=True)
    df_date[0] = df_date[0].apply(lambda x: str(x)[2:])
    df_date["date"] = df_date[1].astype(str) + " " + df_date[0].astype(str)

    list_column_header = ['Product_Type', 'Ref']
    list_column_header = list_column_header + ["to_delete"] + list(df_date["date"])[4:-1]

    # Lecture du fichier excel et suppression des colonnes inutiles
    df = pd.read_excel(excel_file_path, sheet_name=0, skiprows=2)
    df = df.drop(columns=[df.columns[0], df.columns[1], df.columns[2], df.columns[3]])
    list_column_header = [item for item in list_column_header if not ' n' in list_column_header]

    # renommer les colonnes avec les dates
    df.columns = list_column_header

    # Garder que les lignes concernant le flux
    df = df[df['Ref'] == 'Flow']

    # supprimer la colonne que nous n'avons plus besoin (le flux se situe sur le colonne mois + 1)
    df = df.drop(columns=["to_delete"])

    # passer des mois en colonnes en ligne (melt the dataframe)
    df = df.melt(id_vars=["Product_Type", "Ref"], var_name="Period", value_name="Value")

    # garder les valuers qui nous intérresse
    df = df[df['Ref'].isin(['Quantity', 'Value', 'Flow'])]

    # aggréger les données avec la fonction somme sur les valeurs
    df = df.groupby(["Product_Type", "Ref", 'Period']).agg('sum').reset_index()

    # passer les valeurs de type de produit en colonnes
    df = df.pivot_table('Value', ['Product_Type', 'Period'], 'Ref').reset_index()

    # Ajouter la company
    df['Company'] = 'VSTAR'

    # Ajouter la Currency
    df['Currency'] = 'USD'

    # Renommer les colonnes
    df = df.rename(
        columns={'Flow': 'Flow_next_month', 'Quantity': 'qty', 'Value': 'amount'})

    df_sprint_dates = utils.get_sprint_dates()

    # merge sprint date with df stock
    df = df.merge(right=df_sprint_dates, how='left', left_on='Period', right_on='period')

    # TODO A DECOMMENTER
    """
    df['sprint_date_filter'] = df['sprint_date'].apply(lambda str(x): datetime.strptime(x, '%d/%m/%Y') <
                                                                 datetime.strptime(
                                                                     '01' + datetime.now().strftime('/%m/%Y'),
                                                                     '%d/%m/%Y'))

    df = df[df['sprint_date_filter'] == True]

    df = df.drop(columns='sprint_date_filter')
    """

    df = df[['Period', 'Company', 'Product_Type', 'Flow_next_month']]

    df = utils.clean_add_sprint_dates(df)

    return df


def treat_mul_rat(v_file_name, v_company):
    if v_company == 'Mulheim':
        df_rat_mul = pd.read_excel(v_file_name, sheet_name='MH', skiprows=2)
    elif v_company == 'Rath Plug':
        df_rat_mul = pd.read_excel(v_file_name, sheet_name='Plug', skiprows=2)
    else:
        raise NameError('Wrong parameter, "v_company" should equal "Mulheim" or "Rath Plug"')

    df_rat_mul = df_rat_mul.rename(columns={df_rat_mul.columns[0]: 'product_type'})

    yield_rat_mul = df_rat_mul[df_rat_mul['product_type'] == 'Rolling Yield'].iloc[0][1]

    df_rat_mul = df_rat_mul[df_rat_mul['product_type'].isin(['Finished Goods Flow', 'Billets Flow', 'Rolling Yield'])]
    # .rename(columns={'IRIS Delivery Quota': '5 - Finished goods', 'Rolling Production Plan': '3 - Billet'})

    df_rat_mul = df_rat_mul.T.reset_index()

    df_rat_mul.columns = list(df_rat_mul.loc[0])

    df_rat_mul = df_rat_mul[2:len(df_rat_mul)]

    df_rat_mul['Billets Flow'] = df_rat_mul['Billets Flow'].astype(float) * df_rat_mul['Rolling Yield'].astype(float)

    df_rat_mul = df_rat_mul.drop(columns='Rolling Yield')

    df_rat_mul = df_rat_mul.T.reset_index()

    df_rat_mul.columns = list(df_rat_mul.loc[0])

    df_rat_mul = df_rat_mul[1:len(df_rat_mul)]

    df_rat_mul = df_rat_mul.melt(id_vars=["product_type"], var_name="period", value_name="value")

    df_rat_mul['match_reg'] = df_rat_mul['period'].apply(lambda x: utils.match_regex(r"([12]\d{3}-(0[1-9]|1[0-2]))", x))

    df_rat_mul = df_rat_mul[df_rat_mul['match_reg'] == True].drop(columns='match_reg').reset_index(drop=True)

    df_rat_mul['product_type'] = df_rat_mul['product_type'].apply(
        lambda x: '5 - Finished goods' if x == 'Finished Goods Flow' else (
            '3 - Billet' if x == 'Billets Flow' else (
                '4 - WIP' if x == '4 - WIP' else 'error')))

    # df_rat_mul['value'] = df_rat_mul['value'].astype(float)

    df_rat_mul['value'] = df_rat_mul['value'].apply(lambda x: float(str(x).replace(' ', '')))

    df_rat_mul_tmp = df_rat_mul.groupby(['period']).agg(sum).reset_index()
    df_rat_mul_tmp['value'] = df_rat_mul_tmp['value'] / 2
    df_rat_mul_tmp['product_type'] = '4 - WIP'

    df_rat_mul = pd.concat([df_rat_mul, df_rat_mul_tmp]).reset_index(drop=True)

    df_srpint_dates = utils.get_sprint_dates()
    df_srpint_dates['date_join'] = df_srpint_dates['sprint_date'].apply(
        lambda x: datetime.strptime(x, "%d/%m/%Y").strftime("%Y-%m"))

    df_rat_mul = df_rat_mul.merge(right=df_srpint_dates, how='left', left_on='period', right_on='date_join')
    df_rat_mul = df_rat_mul[~df_rat_mul['sprint_date'].isnull()]

    df_rat_mul["sprint_date"] = df_rat_mul["sprint_date"].apply(lambda x: datetime.strptime(x, "%d/%m/%Y"))
    # TODO à décommenter
    # df_rat_mul = df_rat_mul[df_rat_mul['sprint_date'] < datetime.now()]

    df_rat_mul = df_rat_mul.drop(columns=['period_x', 'date_join'])

    df_rat_mul['sprint_date'] = df_rat_mul['sprint_date'].astype(str)
    df_rat_mul['sprint_date'] = df_rat_mul['sprint_date'].apply(
        lambda x: datetime.strptime(x, "%Y-%m-%d").strftime("%d/%m/%Y"))

    df_rat_mul['company'] = v_company

    df_rat_mul = df_rat_mul[['period_y', 'sprint_date', 'company', 'product_type', 'value']].rename(
        columns={'period_y': 'period'})

    return df_rat_mul


def get_vsb_reference_tab(v_hdfs_path_raw, v_site_name, v_client_hdfs):
    def normalized_product_type(cell):
        if cell == 'Billets':
            return '3 - Billet'
        elif cell == 'Semi-Finished':
            return '4 - WIP'
        elif cell == 'Finished':
            return '5 - Finished goods'

    list_files_vsb = v_client_hdfs.list(v_hdfs_path_raw + v_site_name)
    list_month = []
    list_file = []
    list_year = []
    df_files = pd.DataFrame()

    # identifier le fichier le plus récent
    for file in list_files_vsb:
        try:
            list_year.append(int(file.split('.')[0][-6:-2]))
            list_month.append(int(file.split('.')[0][-2:]))
            list_file.append(file)
        except ValueError:
            pass

    df_files['files'] = list_file
    df_files['months_nb'] = list_month
    df_files['year'] = list_year

    # Lire le fichier qui le plus récent. Qui a le mois le plus élevé de l'année en cours
    if len(df_files[(df_files['year'] == datetime.now().year)]) == 0:
        nameFile = \
        df_files[(df_files['year'] == datetime.now().year - 1) & (df_files['months_nb'] == max(df_files['months_nb']))][
            'files'].iloc[0]
    else:
        nameFile = \
        df_files[(df_files['year'] == datetime.now().year) & (df_files['months_nb'] == max(df_files['months_nb']))][
            'files'].iloc[0]

    df_reference = pd.read_excel(nameFile, sheet_name='10_Stock_Point_Id')

    df_reference['Type of product'] = df_reference['Type of product'].apply(lambda x: normalized_product_type(x))

    return df_reference


def treat_vsb_files(v_hdfs_path_histo, v_hdfs_path_raw, v_hdfs_path_error, v_site_name, v_client_hdfs, v_logger):
    list_files_vsb = v_client_hdfs.list(v_hdfs_path_raw + v_site_name)
    if not list_files_vsb:
        raise NameError('There is no VSB file')

    df_flow_vsb = pd.DataFrame()
    for my_file in list_files_vsb:
        utils.download_file_from_hdfs(v_hdfs_path_raw, v_site_name + '/' + my_file, v_client_hdfs)
        v_logger.info('treating file: ' + my_file)

        if my_file.startswith('Dynamic_'):
            df_flow_vsb = df_flow_vsb.append(
                pd.read_excel(my_file, sheet_name='8_Invoice_Extract', skiprows=2, header=None).filter(items=[0, 1, 2, 3, 4, 5]))
            df_flow_vsb = df_flow_vsb.append(
                pd.read_excel(my_file, sheet_name='7_Cons_Extract', skiprows=2, header=None).filter(items=[0, 1, 2, 3, 4, 5]))

        elif my_file.startswith('VSB raw material'):
            df_flow_vsb_raw_mat = pd.read_excel(my_file, sheet_name='VSB RM flow', skiprows=2)
            df_flow_vsb_raw_mat['date_tmp'] = df_flow_vsb_raw_mat['Date'].apply(lambda x: \
                                                                                    datetime.strptime(x,
                                                                                                      "%B %Y").strftime(
                                                                                        "%b %y"))
            df_flow_vsb_raw_mat['company'] = 'VSB'

            df_sprint_dates = utils.get_sprint_dates()

            df_flow_vsb_raw_mat = df_flow_vsb_raw_mat.merge(right=df_sprint_dates, how='left', left_on='date_tmp',
                                                            right_on='period')

            df_flow_vsb_raw_mat = df_flow_vsb_raw_mat.rename(
                columns={'Type': 'product_type', 'Quantity (tons)': 'flow_next_month'})
            df_flow_vsb_raw_mat = df_flow_vsb_raw_mat[
                ['period', 'sprint_date', 'company', 'product_type', 'flow_next_month']]
            df_flow_vsb_raw_mat = df_flow_vsb_raw_mat[~df_flow_vsb_raw_mat['flow_next_month'].isnull()]

        else:
            error_message = 'File name is not correct. Should start with "Dynamic_" or "VSB raw material": ' + my_file
            v_logger.error(error_message)
            utils.push_flag(v_hdfs_path_error, 'invalidate_flow_vsb_flag_error', v_client_hdfs, error_message)

    df_flow_vsb = df_flow_vsb.rename(
        columns={0: 'sprint_date', 1: 'year', 2: 'week_no', 3: 'Site', 4: 'Stock Point name', 5: 'flow_next_month'})

    df_reference_product_type_vsb = get_vsb_reference_tab(hdfs_path_raw, v_site_name, v_client_hdfs)

    df_flow_vsb = df_flow_vsb.merge(right=df_reference_product_type_vsb, how='left', on=['Stock Point name'])

    df_flow_vsb = df_flow_vsb[~df_flow_vsb['Stock Point name'].isin(['LC - Finishing', 'Transit to Barreiro'])]

    df_flow_vsb['company'] = v_site_name

    df_sprint_dates = utils.get_sprint_dates()
    df_sprint_dates['sprint_date_new'] = df_sprint_dates['sprint_date'].apply(lambda x: x[-7:])

    df_flow_vsb['sprint_date_new'] = df_flow_vsb['sprint_date'].apply(
        lambda x: datetime.strptime(str(x), '%Y-%m-%d %H:%M:%S').strftime('%m/%Y'))

    df_flow_vsb = df_flow_vsb.merge(right=df_sprint_dates, how='left', on='sprint_date_new')

    df_flow_vsb = df_flow_vsb.rename(columns={'sprint_date_y': 'sprint_date'})

    df_flow_vsb = df_flow_vsb.rename(columns={'Type of product': 'product_type'})
    df_flow_vsb = df_flow_vsb[['period', 'sprint_date', 'company', 'product_type', 'flow_next_month']]

    df_flow_vsb = pd.concat([df_flow_vsb, df_flow_vsb_raw_mat], ignore_index=True)

    df_flow_vsb = df_flow_vsb.groupby(["product_type", "sprint_date", 'company', 'period']).agg('sum').reset_index()

    df_flow_vsb = df_flow_vsb[['period', 'sprint_date', 'company', 'product_type', 'flow_next_month']]

    # Calculer le WIP qui est égale à la moynne de la somme des Billets et des finished goods
    for date in df_flow_vsb[df_flow_vsb['product_type'].isin(['3 - Billet', '5 - Finished goods'])][
        'sprint_date'].unique():
        v_wip = np.mean([ \
            int(df_flow_vsb.loc[(df_flow_vsb['sprint_date'] == date) & (
                    df_flow_vsb['product_type'] == '3 - Billet'), 'flow_next_month']), \
            int(df_flow_vsb.loc[(df_flow_vsb['sprint_date'] == date) & (
                    df_flow_vsb['product_type'] == '5 - Finished goods'), 'flow_next_month'])])

        df_flow_vsb.loc[(df_flow_vsb['sprint_date'] == date) & \
                        (df_flow_vsb['product_type'] == '4 - WIP'), 'flow_next_month'] = v_wip

    for my_file in list_files_vsb:
        utils.flow_log_file(v_hdfs_path_raw, v_hdfs_path_histo, my_file, v_site_name, v_client_hdfs)

    return df_flow_vsb


# MAIN
try:
    # déclaration du logger
    # create logger
    logger = logging.getLogger('Treat Flow Data')
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(filename)s (line: %(lineno)d) - %(name)s - %(message)s',
        datefmt='%d/%m/%Y %H:%M:%S')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.info('Starting flow program')

    # déclaration du client HDFS
    client_hdfs = utils.return_client_hdfs(os.environ['USER_PRI'])
    # client_hdfs = InsecureClient('http://' + os.environ['IP_HDFS'] + ':' + os.environ['PORT_HDFS'],

    hdfs_path_error = utils.add_backslash(sys.argv[4])
    hdfs_path_raw = utils.add_backslash(sys.argv[1])
    hdfs_path_histo = utils.add_backslash(sys.argv[2])
    hdfs_path_target = utils.add_backslash(sys.argv[3])
    dateFilter = datetime.now().replace(day=1)

    logger.info('hdfs_path_raw: ' + hdfs_path_raw)
    logger.info('hdfs_path_histo: ' + hdfs_path_histo)
    logger.info('hdfs_path_target: ' + hdfs_path_target)
    logger.info('hdfs_path_error: ' + hdfs_path_error)
    logger.info('dateFilter: ' + datetime.strftime(dateFilter, '%d/%m/%Y'))

    test_argv = sys.argv[5:len(sys.argv)]
except:
    error_message = 'Error with parameters.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'flow_parameters_flag_error')
    utils.push_flag(hdfs_path_error, 'flow_parameters_flag_error', client_hdfs, error_message)

for el in sys.argv[5:len(sys.argv)]:
    try:

        logger.info('Treating file' + hdfs_path_raw + el)
        hdfs_path_file = hdfs_path_raw + el
        site_name = hdfs_path_file.split('/')[len(hdfs_path_file.split('/')) - 2]
        file_name = hdfs_path_file.split('/')[len(hdfs_path_file.split('/')) - 1]
        output_file_name = site_name.split('.')[0] + '_flow.csv'

        logger.info('hdfs_path_file: ' + hdfs_path_file)
        logger.info('site_name: ' + site_name)
        logger.info('file_name: ' + file_name)
        logger.info('output_file_name: ' + output_file_name)

        if site_name != 'VSB':
            utils.download_file_from_hdfs(hdfs_path_raw, site_name + '/' + file_name, client_hdfs)

        logger.info('treating company: ' + site_name)
        logger.info('treating file: ' + file_name)

        if site_name == 'VOGFR':
            df_flow_vogfr = treat_vogfr_excel_file(file_name)
            df_flow_vogfr = utils.filter_df_date(df_flow_vogfr, 'sprint_date', dateFilter)
            utils.flow_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_flow_vogfr, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'Tianda':
            df_flow_tianda = treat_tianda_excel_file(file_name)
            df_flow_tianda = utils.filter_df_date(df_flow_tianda, 'sprint_date', datetime.now().replace(day=1))
            utils.flow_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_flow_tianda, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'VSB':
            df_flow_vsb = treat_vsb_files(hdfs_path_histo, hdfs_path_raw, hdfs_path_error, site_name, client_hdfs,
                                          logger)
            df_flow_vsb = utils.filter_df_date(df_flow_vsb, 'sprint_date', dateFilter)
            output_file_name = 'vsb_flow.csv'
            utils.push_file_hdfs(df_flow_vsb, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'VSTAR':
            df_flow_vstar = treat_vstar_excel_file(file_name)
            df_flow_vstar = utils.filter_df_date(df_flow_vstar, 'sprint_date', dateFilter)
            utils.flow_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_flow_vstar, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'Mulheim & Rath plug':
            logger.info('treating file: ' + file_name + " for Mulheim")
            # site_name += '_f'
            df_mulheim = treat_mul_rat(file_name, 'Mulheim')
            df_mulheim = utils.filter_df_date(df_mulheim, 'sprint_date', dateFilter)
            utils.push_file_hdfs(df_mulheim, hdfs_path_target + 'Mulheim_' + output_file_name, client_hdfs)

            logger.info('treating file: ' + file_name + " for Rath Plug")
            df_Rath_Plug = treat_mul_rat(file_name, 'Rath Plug')
            df_Rath_Plug = utils.filter_df_date(df_Rath_Plug, 'sprint_date', dateFilter)
            utils.flow_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_Rath_Plug, hdfs_path_target + 'Rath_Plug_' + output_file_name, client_hdfs)
        else:
            raise NameError('site_name is incorrect: ' + site_name)

    except:
        error_message = 'Error while treating : ' + site_name + '\n' + traceback.format_exc()
        logger.error(error_message)
        logger.info('Pushing error flag file in: ' + hdfs_path_error + 'flow_flag_error_' + site_name)
        utils.push_flag(hdfs_path_error, 'flow_flag_error_' + site_name, client_hdfs, error_message)

try:
    logger.info("Invalidate Impala Metadata")
    utils.invalidate_impala_metadata()
except:
    error_message = 'Error Invalidate Impala Metadata.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'invalidate_flow_flag_error')
    utils.push_flag(hdfs_path_error, 'invalidate_flow_flag_error', client_hdfs, error_message)