import os
from datetime import datetime
import ibis
import re
import traceback
from hdfs.util import HdfsError
from pandas.io.json import json_normalize
from hdfs import InsecureClient


try:
    from SaagieConnect import QueryOpenDataSoftApi
except:
    import pri.SaagieConnect as QueryOpenDataSoftApi


def filter_df_date(df, column_date_to_filter, date_filter):
    df['filter'] = df[column_date_to_filter].apply(lambda x: datetime.strptime(x, '%d/%m/%Y') < date_filter)
    df = df[df['filter']].drop(columns=['filter'])
    return df


# Utils
def add_backslash(path):
    if not path.endswith('/'):
        return path + '/'
    else:
        return path


def format_date_for_join(mydate):
    try:
        return datetime.strptime(str(mydate), '%Y-%m-%d %H:%M:%S').strftime("%d/%m/%Y")
    except ValueError:
        return mydate


def clean_period_sprint_date(raw):
    raw = raw.fillna('0')
    if raw['sprint_date'] == '0':
        return raw
    else:
        raw['Period'] = raw['period']
        return raw


def match_regex(pattern, x):
    if re.fullmatch(pattern, x):
        return True
    else:
        return False


def clean_period(df):
    # get sprint dates
    df_sprint_dates = get_sprint_dates()

    # format dates for join
    df['Period'] = df['Period'].apply(lambda x: format_date_for_join(x))

    # merge flow dataframe and flow dataframe
    df = df.merge(right=df_sprint_dates, how='left', left_on='Period', right_on='sprint_date')

    # clean period sprint date
    df = df.apply(lambda raw: clean_period_sprint_date(raw), axis=1)

    # drop useless columns from table sprint dates
    df = df.drop(["period", "sprint_date"], axis=1)

    return df


def clean_add_sprint_dates(df):
    df = clean_period(df)

    df_sprint_dates = get_sprint_dates()

    df = df.merge(right=df_sprint_dates, how='left', left_on='Period', right_on='period')

    df = df[['Period', 'sprint_date', 'Company', 'Product_Type', 'Flow_next_month']]
    return df


# HDFS Utils
def push_file_hdfs(df, file_path, v_client_hdfs):
    """
    Writing a dataframe as a file in HDFS
    df: DataFrame pandas: dataframe containing the data to store
    file_path: string: Path + name of the file to store
    v_client_hdfs: string: v_client_hdfs
    """
    with v_client_hdfs.write(file_path, encoding='utf-8', overwrite=True) as writer:
        df.to_csv(writer, header=False, sep=';', index=False)

    v_client_hdfs.set_permission(file_path, 770)
    v_client_hdfs.set_replication(file_path, 3)
    v_client_hdfs.set_acl(file_path, "user:impala:rwx", clear=False)
    v_client_hdfs.set_acl(file_path, "group:pri:rwx", clear=False)
    return 1


def download_file_from_hdfs(v_hdfs_path_raw, v_file_name, v_client_hdfs):
    """
    push error flag into HDFS
    v_hdfs_path: string: HDFS path where to store the error flag
    flag_name: string: Name of the file
    v_client_hdfs: string: v_client_hdfs
    """
    # Télécharger le fichier de référence
    v_client_hdfs.download(v_hdfs_path_raw + v_file_name, '.', overwrite=True, n_threads=1, temp_dir=None)
    return 1


def create_local_flag_file(flag_name, data=""):
    if os.path.exists(flag_name):
        os.remove(flag_name)
    f = open(flag_name, "w+")
    f.write(data)
    f.close
    os.chmod(flag_name, 777)
    return 1


def push_flag(v_hdfs_path, flag_name, v_client_hdfs, data=""):
    """
    push error flag into HDFS
    v_hdfs_path: string: HDFS path where to store the error flag
    flag_name: string: Name of the file
    v_client_hdfs: string: HDFS Client
    """
    create_local_flag_file(flag_name, data)
    v_client_hdfs.upload(v_hdfs_path, flag_name, overwrite=True)
    v_client_hdfs.set_permission(v_hdfs_path + flag_name, 770)
    v_client_hdfs.set_replication(v_hdfs_path + flag_name, 3)
    v_client_hdfs.set_acl(v_hdfs_path + flag_name, "user:impala:rwx", clear=False)
    v_client_hdfs.set_acl(v_hdfs_path + flag_name, "group:pri:rwx", clear=False)
    return 1


# Impala Utils
def get_list_product_type_impala(v_ibis_client):
    """
    Getting the PRI product_type table from Impala
    """
    # ====== Reading table ======
    # Selecting data with a SQL query
    # limit=None to get the whole table, otherwise will only get 10000 first lines
    df = query_impala(v_ibis_client, 'select * from pri.m_product_type')
    return list(df['product_type'])


def get_sprint_dates():
    """
    Getting the sprint dates table from the Vallourec internal opendata:
    https://internal-vallourec.opendatasoft.com/explore/dataset/vallourec-sprint-calendar/information/
    """
    my_api_ods = QueryOpenDataSoftApi(url_ods=os.environ['URL_ODS']  # URL_ODS
                                      , api_key=os.environ['API_KEY_ODS_AP'])
    year_now = str(datetime.today().year)
    response = my_api_ods.search_dataset(dataset_name="vallourec-sprint-calendar",
                                         param_search="year>= 2019 AND is_sprint_day=CLOSING")
    # year>=2019 AND is_sprint_day=CLOSING

    df_sprint_dates = json_normalize(response.json()['records'])

    df_sprint_dates = df_sprint_dates[df_sprint_dates['fields.is_sprint_day'] == 'CLOSING']

    df_sprint_dates['sprint_date'] = df_sprint_dates['fields.date'] \
        .apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime("%d/%m/%Y"))
    df_sprint_dates['period'] = df_sprint_dates['fields.date'] \
        .apply(lambda x: datetime.strptime(x, '%Y-%m-%d').strftime("%b %y"))  #

    return df_sprint_dates[['period', 'sprint_date']].reset_index(drop=True)


def query_impala(v_ibis_client, query=''):
    """
    Query Impala with a custom query and client
    """
    requete = v_ibis_client.sql(query)
    df = requete.execute(limit=None)
    return df


def invalidate_impala_metadata():
    # TODO changer le mode de connexion impala (tester la connexion au DN1 si, ça échoue se connecter au DN2 etc..)
    # TODO suite: en passant par l'API SAAGIE pour récupérer les IP impala de tous les DataNaodes
    # TODO changer le mode de récupération de la table sprint dates -> OpenDataSoft

    # Client Impala Spécifique à l'invalidate Metadata (besoin de droit sentry sur le "server" pour faire cette action
    # même pour la MAJ sur un BDD spécifique)
    ibis_hdfs = ibis.hdfs_connect(host=os.environ['IP_HDFS'], port=int(os.environ['PORT_HDFS']))
    ibis_client = ibis.impala.connect(host=os.environ['IP_IMPALA'], port=int(os.environ['PORT_IMPALA']),
                                      hdfs_client=ibis_hdfs, user=os.environ['USER_PRI_INVALIDATE'],
                                      password=os.environ['USER_PRI_INVALIDATE_PWD'],
                                      auth_mechanism='PLAIN', database=os.environ['IMPALA_BDD_PRI'],
                                      use_ssl=bool(os.environ['IMPALA_SSL_ACTIVATED'] == "1"))
    ibis_client.invalidate_metadata()
    return 1


def flow_log_file(v_hdfs_path_raw, v_dest_dir_histo, v_file_name, v_site_name, v_client_hdfs):
    try:
        v_hdfs_source_path_file = v_hdfs_path_raw + v_site_name + '/' + v_file_name
        v_hdfs_dest_path_file = v_dest_dir_histo + v_site_name + '/' + datetime.now().strftime('%Y%m%d') + '_' +\
                                v_file_name

        # Créer et affecter des droits au directory cible si non existant
        v_client_hdfs.makedirs(v_dest_dir_histo + v_site_name + '/', permission=None)
        v_client_hdfs.set_permission(v_dest_dir_histo + v_site_name + '/', 770)
        v_client_hdfs.set_acl(v_dest_dir_histo + v_site_name + '/', "user:impala:rwx", clear=False)
        v_client_hdfs.set_acl(v_dest_dir_histo + v_site_name + '/', "group:pri:rwx", clear=False)

        # Delete file if already exists
        v_client_hdfs.delete(v_hdfs_dest_path_file, recursive=False)

        # Déplacer le fichier pour historisation
        v_client_hdfs.rename(v_hdfs_source_path_file, v_hdfs_dest_path_file)
        v_client_hdfs.set_permission(v_hdfs_dest_path_file, 770)
        v_client_hdfs.set_replication(v_hdfs_dest_path_file, 3)
        v_client_hdfs.set_acl(v_hdfs_dest_path_file, "user:impala:rwx", clear=False)
        v_client_hdfs.set_acl(v_hdfs_dest_path_file, "group:pri:rwx", clear=False)

        if v_site_name in ['VSTAR', 'VOGFR', 'VSB']:
            # Upload le fichier pour traitement inventory
            # TODO: il n'y a pas de commande copy dans insecureClient, obliger de download / upload le fichier (à revoir)
            my_hdfs_path = v_hdfs_path_raw + v_site_name
            v_client_hdfs.upload(local_path=v_file_name, hdfs_path=my_hdfs_path)
            v_client_hdfs.set_replication(my_hdfs_path+'/'+v_file_name, 3)
            v_client_hdfs.set_permission(my_hdfs_path+'/'+v_file_name, 770)
            v_client_hdfs.set_replication(my_hdfs_path+'/'+v_file_name, 3)
            v_client_hdfs.set_acl(my_hdfs_path+'/'+v_file_name, "user:impala:rwx", clear=False)
            v_client_hdfs.set_acl(my_hdfs_path+'/'+v_file_name, "group:pri:rwx", clear=False)
            return 1

    except HdfsError:
        raise ValueError('Path source: ' + v_hdfs_source_path_file + '\n' +
                         'Path destination: ' + v_hdfs_dest_path_file
                         + '\n' + traceback.format_exc())


def inventory_log_file(v_hdfs_path_raw, v_dest_dir_histo, v_file_name, v_site_name, v_client_hdfs):
    try:
        v_hdfs_source_path_file = v_hdfs_path_raw + v_site_name + '/' + v_file_name
        v_hdfs_dest_path_file = v_dest_dir_histo + v_site_name + '/' + datetime.now().strftime('%Y%m%d') + '_' + \
                                v_file_name

        # Créer et affecter des droits au directory cible si non existant
        v_client_hdfs.makedirs(v_dest_dir_histo + v_site_name, permission=None)
        v_client_hdfs.set_permission(v_dest_dir_histo + v_site_name, 770)
        v_client_hdfs.set_acl(v_dest_dir_histo + v_site_name, "user:impala:rwx", clear=False)
        v_client_hdfs.set_acl(v_dest_dir_histo + v_site_name, "group:pri:rwx", clear=False)

        # Delete file if already exists
        v_client_hdfs.delete(v_hdfs_dest_path_file, recursive=False)

        # Déplacer le fichier pour historisation
        v_client_hdfs.rename(v_hdfs_source_path_file, v_hdfs_dest_path_file)
        v_client_hdfs.set_permission(v_hdfs_dest_path_file, 770)
        v_client_hdfs.set_replication(v_hdfs_dest_path_file, 3)
        v_client_hdfs.set_acl(v_hdfs_dest_path_file, "user:impala:rwx", clear=False)
        v_client_hdfs.set_acl(v_hdfs_dest_path_file, "group:pri:rwx", clear=False)
    except HdfsError:
        raise ValueError('PRI | Path source: ' + v_hdfs_source_path_file + '\n' +
                         'PRI | Path destination: ' + v_hdfs_dest_path_file
                         + '\n' + traceback.format_exc())

def get_url_active_namenode(user):
    HDFS_URLS = [os.environ['URL_NN1'] + ':' + os.environ['PORT_HDFS'],
                 os.environ['URL_NN2'] + ':' + os.environ['PORT_HDFS']]
    cpt = 1
    for url in HDFS_URLS:
        hadoop = InsecureClient(url)
        try:
            hadoop.status('/')
            return url
        except:
            if cpt == len(HDFS_URLS):
                raise NameError("No NameNode available" + '\n' + traceback.format_exc())
            else:
                cpt += 1

def return_client_hdfs(user):
    url = get_url_active_namenode(user)
    client_hdfs = InsecureClient(url, user=user)
    return client_hdfs

