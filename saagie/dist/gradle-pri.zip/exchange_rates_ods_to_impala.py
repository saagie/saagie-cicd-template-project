import pandas as pd
import os
from pandas.io.json import json_normalize
from datetime import datetime
import traceback
import logging
from hdfs import InsecureClient
import sys

try:
    from SaagieConnect import QueryOpenDataSoftApi
except:
    import pri.SaagieConnect as QueryOpenDataSoftApi
try:
    import utils as utils
except:
    import pri.utils as utils

# MAIN
try:
    # déclaration du client HDFS
    client_hdfs = utils.return_client_hdfs(os.environ['USER_PRI_INVALIDATE'])

    # déclaration du logger
    # create logger
    logger = logging.getLogger('PRI | Treat Flow Data')
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(filename)s (line: %(lineno)d) - %(name)s - %(message)s',
        datefmt='%d/%m/%Y %H:%M:%S')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.info('PRI | Starting exchange rate program')

    hdfs_path_impala_table_exchange_rates = utils.add_backslash(sys.argv[1])
    hdfs_path_error = utils.add_backslash(sys.argv[2])
    ods_dataset_id = sys.argv[3]
    ods_query_paramter = sys.argv[4]

    logger.info('PRI | hdfs_path_impala_table_exchange_rates: ' + hdfs_path_impala_table_exchange_rates)
    logger.info('PRI | hdfs_path_error: ' + hdfs_path_error)
    logger.info('PRI | ods_dataset_id: ' + ods_dataset_id)
    logger.info('PRI | ods_query_paramter: ' + ods_query_paramter)

    # déclaration du client OpenDataSoft
    my_api_ods = QueryOpenDataSoftApi(url_ods=os.environ['URL_ODS']  # URL_ODS
                                      , api_key=os.environ['API_KEY_ODS_AP'])


except:
    error_message = 'PRI | Error with parameters.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('PRI | Pushing error flag file in: ' + hdfs_path_error + 'exchange_rates_parameters_flag_error')
    utils.push_flag(hdfs_path_error, 'exchange_rates_parameters_flag_error', client_hdfs, error_message)

try:
    response = my_api_ods.search_dataset(dataset_name=ods_dataset_id, param_search=ods_query_paramter)

    df_exchange_rates = json_normalize(response.json()['records']) \
        .drop(columns=['datasetid', 'fields.table', 'recordid', 'record_timestamp'])

    df_exchange_rates_cny = df_exchange_rates[df_exchange_rates['fields.vs_eur'] == 'CNY'].drop(
        columns=['fields.vs_eur']).T
    df_exchange_rates_brl = df_exchange_rates[df_exchange_rates['fields.vs_eur'] == 'BRL'].drop(
        columns=['fields.vs_eur']).T
    df_exchange_rates_USD = df_exchange_rates[df_exchange_rates['fields.vs_eur'] == 'USD'].drop(
        columns=['fields.vs_eur']).T

    df_exchange_rates_cny['from_currency'] = 'CNY'
    df_exchange_rates_brl['from_currency'] = 'BRL'
    df_exchange_rates_USD['from_currency'] = 'USD'

    df_exchange_rates_cny = df_exchange_rates_cny.rename(columns={df_exchange_rates_cny.columns[0]: 'exchange_rate'})
    df_exchange_rates_brl = df_exchange_rates_brl.rename(columns={df_exchange_rates_brl.columns[0]: 'exchange_rate'})
    df_exchange_rates_USD = df_exchange_rates_USD.rename(columns={df_exchange_rates_USD.columns[0]: 'exchange_rate'})
    df_exchange_rates_EUR = df_exchange_rates_USD.copy()
    df_exchange_rates_EUR['exchange_rate'] = 1.0
    df_exchange_rates_EUR['from_currency'] = 'EUR'

    df_exchange_rates = pd.concat(
        [df_exchange_rates_cny, df_exchange_rates_brl, df_exchange_rates_USD, df_exchange_rates_EUR])

    df_exchange_rates['to_currency'] = 'EUR'
    df_exchange_rates['exchange_type'] = 'Closing'

    df_exchange_rates['exchange_rate'] = df_exchange_rates['exchange_rate'].apply(lambda x: 1 / x)

    df_exchange_rates = df_exchange_rates.reset_index().rename(columns={'index': 'date_exchange_rate'})

    df_exchange_rates['date_exchange_rate'] = df_exchange_rates['date_exchange_rate'].apply(
        lambda x: x.replace('fields.', ''))
    df_exchange_rates['date_exchange_rate'] = df_exchange_rates['date_exchange_rate'] \
        .apply(lambda x: datetime.strftime(datetime.strptime(x, '%d_%m_%Y'), '%b %y'))

    df_exchange_rates = df_exchange_rates[
        ['date_exchange_rate', 'from_currency', 'to_currency', 'exchange_type', 'exchange_rate']]

    logger.info('Pushing file: ' + hdfs_path_impala_table_exchange_rates + 'exchange_rates_internal_opendata')
    utils.push_file_hdfs(df_exchange_rates, hdfs_path_impala_table_exchange_rates + "exchange_rates_internal_opendata",
                         client_hdfs)
except:
    error_message = 'Error while treating : ' + 'exchange_rate' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'exchange_rates_flag_error_' + 'exchange_rate')
    utils.push_flag(hdfs_path_error, 'exchange_rates_flag_error_' + 'exchange_rate', client_hdfs, error_message)

try:
    logger.info("Invalidate Impala Metadata")
    utils.invalidate_impala_metadata()
except:
    error_message = 'Error Invalidate Impala Metadata.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'exchange_rates_invalidate_parameters_flag_error')
    utils.push_flag(hdfs_path_error, 'exchange_rates_invalidate_parameters_flag_error', client_hdfs, error_message)