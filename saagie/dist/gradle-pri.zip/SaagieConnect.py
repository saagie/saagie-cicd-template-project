from hdfs import InsecureClient
import ibis
import requests
from sqlalchemy import create_engine
from elasticsearch import Elasticsearch
import urllib.parse


def hdfs_connect(hdfsip, user):
    """
    Connexion to the hdfs - uses hdfsCLI
    :return: client_hdfs -
    """
    # Connecting to Webhdfs by providing hdfs host ip and webhdfs port (50070 by default)
    client_hdfs = InsecureClient('http://' + hdfsip + ':50070', user=user)

    print('Connected to hdfs')
    return client_hdfs


def impala_connect(hdfsip, impalaip, user, pwd):
    """
    Connexion to impala - uses ibis
    :param hdfsip:
    :param impalaip:
    :param user:
    :param pwd:
    :return: client
    """
    # Connecting to Impala by providing Impala host ip and port (21050 by default),credentials and a Webhdfs client
    hdfs = ibis.hdfs_connect(host=hdfsip, port=50070)
    client = ibis.impala.connect(host=impalaip, port=21050, hdfs_client=hdfs, user=user,
                                 password=pwd, auth_mechanism='PLAIN')
    print('Connected to impala')
    return client


def hive_connect(hdfsip, hiveip, user, pwd):
    """
    Connexion to hive - uses ibis
    :param hdfsip:
    :param hiveip:
    :param user:
    :param pwd:
    :return: client
    """
    # ====== Ibis conf (to avoid a bug) ======
    with ibis.config.config_prefix('impala'):
        ibis.config.set_option('temp_db', '`__ibis_tmp`')

    # Connecting to Impala by providing Impala host ip and port (21050 by default),credentials and a Webhdfs client
    hdfs = ibis.hdfs_connect(host=hdfsip, port=50070)
    client = ibis.impala.connect(host=hiveip, port=10000, hdfs_client=hdfs, user=user,
                                 password=pwd, auth_mechanism='PLAIN')
    print('Connected to hive')
    return client


def mysql_connect(user, pwd,sqlip, sqlport):
    """
    Connection to MySQL, uses mysql connector and sqlachelchemy
    Beware, use pip install mysql-connector==2.1.4
    :param user:
    :param pwd:
    :param sqlip:
    :param sqlport:
    :return:
    """

    # ====== Connection ====== #
    # Connecting to mysql by providing a sqlachemy engine
    engine = create_engine('mysql+mysqlconnector://'+user+':'+pwd+'@'+sqlip+':'+sqlport+'/sandbox', echo=False)

    return engine


def postgresql_connect(user,pwd,postgreip,postgreport, db):
    """
    Connection to postgreSQL, uses psycopg2 and sqlalchemy
    :param user:
    :param pwd:
    :param postgreip:
    :param postgreport:
    :param db:
    :return:
    """

    # ====== Connection ======
    # Connecting to PostgreSQL by providing a sqlachemy engine
    engine = create_engine('postgresql://'+user+':'+pwd+'@'+postgreip+':'+postgreport+'/'+db, echo=False)

    return engine


def elastic_connect(elastip, elastiport):
    """
    Connection to Elasticsearch, uses elasticsearch
    :param elastip:
    :param elastiport:
    :return:
    """

    # ====== Connection ====== #
    # Connection to ElasticSearch
    es = Elasticsearch(['http://' + elastip + ':' + elastiport],timeout=600)
    return es

class SharepointApi:
    """
    Classe pour requêter l'API sharepoint
    
    TODO: Faire la gestion de l'expiration de token
    TODO: Compléter les requêtes
    TODO: faire la gestion des erreurs
    """
    
    def __init__(self, host, site, client_secret, client_id, tenant_id, url_access="", principal=""):
        # Déclaration des variables sharepoint
        # Nom de domaine
        self.host = host
        # Nom du domaine pour récupérer le token (sera toujours le même)
        if not url_access:
            self.url_access = "accounts.accesscontrol.windows.net/"
        else:
            self.url_access = url_access
            
        # Nom de la team / site / autre où les fichiers ou autres seront stockés (visible dans l'url quand dans le dossier sharepoint)
        self.site = site
        
        # Client secret à demander à l'administrateur Office365
        self.client_secret = client_secret
        
        # Client ID à demander à l'administrateur Office365
        self.client_id = client_id
        
        # Tenant id à demander à l'administrateur Office365
        self.tenant_id = tenant_id
        
        # Principal qui ne change pas (à vérifier)
        if not principal:
            self.principal = "00000003-0000-0ff1-ce00-000000000000"
        else:
            self.principal = principal
            
        # Url principale
        self.api_url = "https://" + self.host + "/teams/"+ self.site + "/_api/web/"
        
        # Url de demande de token
        self.api_url_token = "https://" + self.url_access + self.tenant_id + "/tokens/OAuth/2"
        
        # Token d'identification
        self.get_token()
    
    def get_token(self):
        payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data;" + \
            "name=\"grant_type\"\r\n\r\nclient_credentials\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition:" + \
            "form-data; name=\"client_id\"\r\n\r\n" + self.client_id + "@" + self.tenant_id + "\r\n" + \
            "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data;" + \
            "name=\"client_secret\"\r\n\r\n"+ self.client_secret + "\r\n" + \
            "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data;" + \
            "name=\"resource\"\r\n\r\n" + self.principal + "/" + self.host + \
            "@" + self.tenant_id + "\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--"
        headers = {
            'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
            'cache-control': "no-cache"
            }
        response = requests.request("POST", self.api_url_token, data=payload, headers=headers)
        self.token = response.json()['access_token']
        return 1 # TODO a améliorer

    
    def get_list_files_from_folder(self, path_folder):  
        path = urllib.parse.quote("GetFolderByServerRelativeUrl('" + path_folder + "')/Files", safe='')

        url = self.api_url + path

        headers = {
                'Authorization': "Bearer " + self.token,
                'Accept': "application/json;odata=nometadata",
                'cache-control': "no-cache",
            }

        return requests.request("GET", url, headers=headers).json()
    
    
    def downloadFileFromSharepoint(self, foldername, filename):
        path = urllib.parse.quote("GetFolderByServerRelativeUrl('" + foldername + "')", safe='')

        file_url = urllib.parse.quote("/Files('" + filename + "')/$value", safe = '')

        url = self.api_url + path + file_url

        headers = {
                'Authorization': "Bearer " + self.token,
                'Accept': "application/json;odata=nometadata",
                'cache-control': "no-cache",
            }

        r = requests.request("GET", url, headers=headers, stream=True)
        with open(filename, 'wb+') as f:
            for chunk in r.iter_content(chunk_size=1024): 
                if chunk:
                    f.write(chunk)
                    f.flush()
        return 1 # TODO: A améliorer


class sharepoint_connect():
    """
    Connection to sharepoint, uses requests
    """
    """
    def __init__(self):
        self.client_secret = ""
        self.client_id = ""
        self.url_access = ""  # "https://accounts.accesscontrol.windows.net/f9a418a3-c38d-46ea-9a4c-76378b349da7/tokens/OAuth/2"
        self.url_folder = ""  # "https://serimaxcom.sharepoint.com/sites/cleverscandatarespository-team
        self.lookup_folder = ""
    """ 
       
    def __init__(self, client_secret, client_id, url_access, url_folder = "", lookup_folder = ""):
        self.client_secret = client_secret
        self.client_id = client_id
        self.url_access = url_access
        self.url_folder = url_folder
        self.lookup_folder = lookup_folder
        getAuthorisationToken(self)


    def getAuthorisationToken(self):
        url = self.url_access

        payload = "grant_type=client_credentials&client_id=8a9b0cec-3724-485c-b1d6-47a2194946eb%40f9a418a3-c38d-46ea-9a4c-76378b349da7&client_secret=" + self.client_secret + "%3D&resource=00000003-0000-0ff1-ce00-000000000000%2Fserimaxcom.sharepoint.com%40f9a418a3-c38d-46ea-9a4c-76378b349da7"
        headers = {
            'Content-Type': "application/x-www-form-urlencoded",
            'cache-control': "no-cache",
            'Postman-Token': "3ed8410b-8351-457c-993d-0603dac46db1"
        }

        response = requests.request("POST", url, data=payload, headers=headers, verify=False)

        if r.status_code == 200:
            self.access_token = response.json()['access_token']
        else:
            raise Exception('Error while getting the authorisation Token: ' + response.text)

        return response


    def getListInSharepointFolder(self):
        url = self.url_folder + "/_api/web/GetFolderByServerRelativeUrl%28%27Shared%20Documents/" + self.lookup_folder

        headers = {
            'Authorization': "Bearer " + self.access_token,
            'Accept': "application/json;odata=nometadata",
            'cache-control': "no-cache",
            'Postman-Token': "b47bbc13-7446-4fff-9a03-3cefd3259905"
        }

        response = requests.request("GET", url, headers=headers, verify=False)

        return response


    def getFileInSharepointFromId(self, uniqueid):
        url = self.url_folder + "/_api/web/GetFileById%28%27" + uniqueid + "%27%29/$value"

        headers = {
            'Authorization': "Bearer " + self.access_token,
            'Accept': "application/json;odata=nometadata",
            'cache-control': "no-cache",
            'Postman-Token': "6541fcea-afde-4b16-893d-f2fac2a1a72d"
        }

        response = requests.request("GET", url, headers=headers, verify=False)
        
        return response


class QueryOpenDataSoftApi:
    # full doc: https://internal-vallourec.opendatasoft.com/api/
    # example API console: https://internal-vallourec.opendatasoft.com/api/v1/console/datasets/1.0/search/

    def __init__(self, url_ods, api_key):
        if not url_ods.endswith('/'):
            url_ods += '/'
        self.url = url_ods

        self.api_key = api_key

    def search_dataset(self, dataset_name, param_search):
        full_url = self.url + "records/1.0/search/"

        querystring = {"dataset": dataset_name,
                       "q": param_search,
                       "rows": "-1",
                       "apikey": self.api_key
                       }
        """
        querystring = {"dataset":"vallourec-sprint-calendar","q":"year=2019","rows":"-1",
               "apikey":"dbbd2de2dcba370973700f6168377e36b256004eb3fce7a3b117d91e"}
        """
        headers = {
            'Accept': "*/*",
            'Cache-Control': "no-cache",
            'Host': "internal-vallourec.opendatasoft.com",
            'accept-encoding': "gzip, deflate",
            'Connection': "keep-alive",
            'cache-control': "no-cache"
        }

        return requests.request("GET", full_url, headers=headers, params=querystring)