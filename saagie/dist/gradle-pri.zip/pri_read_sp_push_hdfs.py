from hdfs import InsecureClient
import os
from hdfs.util import HdfsError
import sys
import traceback
import logging

try:
    from SaagieConnect import SharepointApi
    import utils
except:
    import pri.utils as utils
    from pri.SaagieConnect import SharepointApi

try:
    # create logger
    logger = logging.getLogger('PRI | Import Data')
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(filename)s (line: %(lineno)d) - %(name)s - %(message)s',
        datefmt='%d/%m/%Y %H:%M:%S')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.info('Starting read sharepoint and push to HDFS program')

    hdfs_path_raw = utils.add_backslash(sys.argv[1])
    hdfs_path_error = utils.add_backslash(sys.argv[2])
    hdfs_path_config_file = utils.add_backslash(sys.argv[3])

    logger.info('hdfs_path_raw: ' + hdfs_path_raw)
    logger.info('hdfs_path_error: ' + hdfs_path_error)
    logger.info('hdfs_path_config_file: ' + hdfs_path_config_file)

    # déclaration du client HDFS
    try:
        client_hdfs = InsecureClient('http://nn1:50070', 'hdfs')
        ret = client_hdfs.download('my_hdfs_file', 'my_local_path')
    except:
        try:
            client_hdfs = InsecureClient('http://nn2:50070', 'hdfs')
            ret = client_hdfs.download('my_hdfs_file', 'my_local_path')
        except:
            print("no namenode available")

    client_hdfs = utils.return_client_hdfs(os.environ['USER_PRI'])
    # client_hdfs = InsecureClient('http://' + os.environ['IP_HDFS'] + ':' + os.environ['PORT_HDFS'],
    #                             user=os.environ['USER_PRI'])

    # download du fichier de config contenant les fichier sources où télécharger les fichiers sources
    client_hdfs.download(hdfs_path_config_file, '.', overwrite=True, n_threads=1, temp_dir=None)

    # récupération des chemins sharepoint depuis le fichier
    config_file_tmp = hdfs_path_config_file.split('/')
    for el in config_file_tmp:
        if el == '':
            config_file_tmp.remove('')
    config_file = config_file_tmp[len(config_file_tmp) - 1:][0]
    list_folder_source_sp = list(map(lambda x: x.replace('\n', ''), open(config_file, 'r').readlines()))

    logger.info('Getting environement varaibles: ' + hdfs_path_config_file)

    # Déclaration des variables sharepoint
    # Nom de domaine
    host = os.environ['SHAREPOINT_HOST']
    # Nom de la team / site / autre où les fichiers ou autres seront stockés (visible dans l'url quand dans le dossier sharepoint)
    site = os.environ['SP_PRI_SITE']
    # Client ID à demander à l'administrateur Office365
    client_id = os.environ['PRI_CLIENT_ID']
    # Client secret à demander à l'administrateur Office365
    client_secret = os.environ['PRI_SP_SECRET']
    # Tenant id à demander à l'administrateur Office365
    tenant_id = os.environ['PRI_SP_TENANT_ID']

    # (self, host, site, client_secret, client_id, tenant_id, url_access="", principal=""):
    my_sharepointAPI = SharepointApi(host, site, client_secret, client_id, tenant_id)

    list_files = []
except:
    error_message = 'Error while initializing program' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'flag_error_import_folder_init')
    utils.push_flag(hdfs_path_error, 'flag_error_import_folder_init_var', client_hdfs, error_message)
    raise NameError(error_message)

# Boucler sur tous les dossiers sharepoint (tous les fichiers sources de tous les sites)
for folder_name in list_folder_source_sp:
    try:
        logger.info("Sharepoint folder: " + folder_name)

        # Récupérer le nom du site à partir du nom du dossier Sharepoint
        nom_site = folder_name.split('/')[1]
        logger.info("Nom du site: " + nom_site)

        # Récupérer tous la liste de tous les fichiers présents dans le dossier
        list_files = my_sharepointAPI.get_list_files_from_folder(folder_name)

        # Construire le path HDFS cible
        hdfs_path = hdfs_path_raw + nom_site

        # S'assurer que le dossier cible sur HDFS est créé
        client_hdfs.makedirs(hdfs_path, permission=770)

        # Récupérer la liste de tous les fichiers présents dans le dossier cible HDFS (pour éviter des problèmes de copie)
        list_file_hdfs_path = client_hdfs.list(hdfs_path, status=False)

        if len(list_files['value']) == 0:
            raise NameError('The folder doesn\'t exists or there is no file in the sharepoint folder: ' + folder_name)

        # Boucler sur tous les fichiers présent sur sharepoint et les pousser sur HDFS
        for files_json in list_files['value']:
            logger.info("Sharepoint file: " + files_json['Name'])
            file_name = files_json['Name']

            # download file from Sharepoint
            my_sharepointAPI.downloadFileFromSharepoint(foldername=folder_name, filename=file_name)

            """
            Do not delete the existing file, if there is a file, it means the last execution failed

            # This is wrong: deleting file if exists (we are in delete / update mode)
            if file_name in list_file_hdfs_path:
                print("deleting file from HDFS path: " + hdfs_path + file_name)
                client_hdfs.delete(hdfs_path + file_name)
            """
            try:
                # push files to HDFS
                # upload(hdfs_path, local_path, n_threads=1, temp_dir=None, chunk_size=65536, progress=None, cleanup=True, **kwargs)
                logger.info("Pushing file: " + file_name + " to HDFS: " + hdfs_path)
                client_hdfs.delete(hdfs_path+'/'+file_name, recursive=False, skip_trash=True)
                client_hdfs.upload(hdfs_path, file_name)
                client_hdfs.set_permission(hdfs_path+'/'+file_name, 770)
                client_hdfs.set_replication(hdfs_path+'/'+file_name, 3)
                client_hdfs.set_acl(hdfs_path+'/'+file_name, "user:impala:rwx", clear=False)
                client_hdfs.set_acl(hdfs_path+'/'+file_name, "group:pri:rwx", clear=False)
            except HdfsError:
                error_message = "File already exists, the file hasn't been treated or the treatment job has failed: " + hdfs_path + '/' + file_name + '\n' + traceback.format_exc()
                logger.error(error_message)
                logger.info(
                    'Pushing error flag file in: ' + hdfs_path_error + 'flag_error_import_file_' + folder_name.replace(
                        '/', '_'))
                utils.push_flag(hdfs_path_error, 'flag_error_import_file_' + folder_name.replace('/', '_'), client_hdfs,
                                error_message)
            except:
                error_message = "Unexpected error while treating file: " + hdfs_path + '/' + file_name + '\n' + traceback.format_exc()
                logger.error(error_message)
                logger.info(
                    'Pushing error flag file in: ' + hdfs_path_error + 'flag_error_import_file_' + folder_name.replace(
                        '/', '_'))
                utils.push_flag(hdfs_path_error, 'flag_error_import_file_' + folder_name.replace('/', '_'), client_hdfs,
                                error_message)
    except:
        error_message = 'Error while importing folder from sharepoint : ' + folder_name + '\n' + traceback.format_exc()
        logger.error(error_message)
        logger.info(
            'Pushing error flag file in: ' + hdfs_path_error + 'flag_error_import_folder_' + folder_name.replace('/',
                                                                                                                 '_'))
        utils.push_flag(hdfs_path_error, 'flag_error_import_folder_' + folder_name.replace('/', '_'), client_hdfs,
                        error_message)
