import pandas as pd
from hdfs import InsecureClient
import os
import sys
import ibis
from datetime import datetime
from hdfs.util import HdfsError
import traceback
import logging

try:
    import utils as utils
except:
    import pri.utils as utils


# TODO factoriser toutes les fonctions utils dans un fichier séparer
# TODO factoriser les fonctions de traitement dans un fchier séparer


def treat_rat_mul(v_file_name, v_company):  # Mulheim or Rath Plug
    df_rat_mul = pd.read_excel(v_file_name, sheet_name=0, header=None)

    df_rat_mul_header = df_rat_mul[0:4].T.rename(columns={0: "year", 1: "month", 2: "del", 3: "product_type"}).drop(
        columns=['del'])

    df_rat_mul_header['sep'] = ' '
    df_rat_mul_header['sep2'] = '|'
    df_rat_mul_header['year'] = df_rat_mul_header['year'].apply(lambda x: str(x)[-2:])
    df_rat_mul_header['month'] = df_rat_mul_header['month'].apply(lambda x: str(x)[:3])

    df_rat_mul_header['col'] = df_rat_mul_header["month"].astype(str) \
                               + df_rat_mul_header["sep"].astype(str) \
                               + df_rat_mul_header["year"].astype(str)

    my_date = ''
    for index, row in df_rat_mul_header.iterrows():
        if row['col'] != 'nan an':
            my_date = row['col']
        else:
            df_rat_mul_header['col'][index] = my_date

    df_rat_mul_header['col'] = df_rat_mul_header['col'] \
                               + df_rat_mul_header["sep2"].astype(str) \
                               + df_rat_mul_header["product_type"].astype(str)

    df_rat_mul_header['col'][0] = "company"
    df_rat_mul_header['col'][1] = "product_type"
    df_rat_mul.columns = df_rat_mul_header['col']
    df_rat_mul = df_rat_mul[3:]

    # Delete useless rows
    df_rat_mul = df_rat_mul[df_rat_mul['product_type'] == df_rat_mul['product_type']].reset_index(drop=True)

    if v_company == 'Mulheim':
        index_mul_starting = df_rat_mul[df_rat_mul['company'].str.contains('Mülheim')].index[0]
        df_rat_mul = df_rat_mul[index_mul_starting:index_mul_starting + 5].reset_index(drop=True).drop(
            columns=['company'])
        df_rat_mul = df_rat_mul[~df_rat_mul['product_type'].isnull()]
    elif v_company == 'Rath Plug':
        index_rat_starting = df_rat_mul[df_rat_mul['company'].str.contains('Rath Plug')].index[0]
        df_rat_mul = df_rat_mul[index_rat_starting:index_rat_starting + 5].reset_index(drop=True).drop(
            columns=['company'])
        df_rat_mul = df_rat_mul[~df_rat_mul['product_type'].isnull()]
    else:
        raise NameError('PRI | Wrong paramater for method "treat_rat_mulheim" ("rat" or "mul")')

    df_rat_mul = df_rat_mul.melt(id_vars=["product_type"], var_name="period|type_value", value_name="Value")
    df_rat_mul = df_rat_mul[df_rat_mul['product_type'] != 'Product Type']

    # new data frame with split value columns
    new = df_rat_mul["period|type_value"].str.split("|", n=1, expand=True)

    # making separate first name column from new data frame
    df_rat_mul["period"] = new[0]

    # making separate last name column from new data frame
    df_rat_mul["type_value"] = new[1]

    df_rat_mul = df_rat_mul.drop(columns=['period|type_value'])

    df_rat_mul['type_value'] = df_rat_mul['type_value'].apply(lambda x: 'qty' if x == 'In tons' else \
        ('amount' if x == 'In k€' else \
             ('ratio' if x == 'In €/tons' else 'error')))

    df_rat_mul = df_rat_mul[df_rat_mul['type_value'] != 'ratio'].reset_index(drop=True)

    df_rat_mul_qty = df_rat_mul[df_rat_mul['type_value'] == 'qty'].reset_index(drop=True)
    df_rat_mul_amount = df_rat_mul[df_rat_mul['type_value'] == 'amount'].reset_index(drop=True)

    df_rat_mul = df_rat_mul_amount.merge(right=df_rat_mul_qty, how='left', on=['product_type', 'period'],
                                         suffixes=('_left', '_right')) \
        .drop(columns=['type_value_left', 'type_value_right']) \
        .rename(columns={'Value_left': 'amount', 'Value_right': 'qty'})

    df_rat_mul['period'] = df_rat_mul['period'].apply(lambda x: x.title())

    sprint_dates = utils.get_sprint_dates()
    df_rat_mul = df_rat_mul.merge(right=sprint_dates, how='left', on='period')

    df_rat_mul['sprint_date'] = df_rat_mul['sprint_date'].apply(lambda x: datetime.strptime(x, "%d/%m/%Y"))
    # TODO A DECOMMENTER
    # df_rat_mul = df_rat_mul[df_rat_mul['sprint_date'] < datetime.now()]

    df_rat_mul['sprint_date'] = df_rat_mul['sprint_date'].apply(lambda x: x.strftime("%d/%m/%Y"))

    df_rat_mul["currency"] = 'EUR'

    df_rat_mul["company"] = v_company

    df_rat_mul = df_rat_mul[['period', 'sprint_date', 'company', 'product_type', 'qty', 'amount', 'currency']]

    df_rat_mul['amount'] = df_rat_mul['amount'] * 1000
    return df_rat_mul


def treat_vogfr_excel_file(excel_file_path):
    # read_file
    df = pd.read_excel(excel_file_path, sheet_name='WW_Stocks')

    # get sprint dates
    df_sprint_dates = utils.get_sprint_dates()

    # transform dates to the correct format for joining mm/yyyy
    df['Period_tmp'] = df['Period'].apply(
        lambda x: datetime.strptime(utils.format_date_for_join(x), "%d/%m/%Y").strftime("%m/%Y"))

    # format dates in the sprint date table to join on mm/yyyy format
    df_sprint_dates['Period_tmp'] = df_sprint_dates['sprint_date'].apply(
        lambda x: datetime.strptime(x, "%d/%m/%Y").strftime("%m/%Y"))

    # Join dataframe
    df = df.merge(right=df_sprint_dates, how='left', on='Period_tmp')

    # filter rows in 2018
    # df = df[df['Period'] > '2018-12-31'].reset_index(drop=True)

    df = df[['period', 'sprint_date', 'Company', 'Product Type', 'Qty (T)', 'Amount', 'Currency']]

    return df


def treat_tianda_excel_file(excel_file_path, v_ibis_client):
    # Lire le fichier excel
    df_tianda_stock = pd.read_excel(excel_file_path, sheet_name=0, skiprows=0)

    df_tianda_stock = df_tianda_stock.rename(
        columns={'Unnamed: 2': 'product_type', df_tianda_stock.columns[0]: 'column_value_filter'})

    # Get df for the value of stock
    df_tianda_value_stock = df_tianda_stock[df_tianda_stock['column_value_filter'] == 'Valuation billets  RMB/ton'] \
        .drop(columns=['product_type'])

    # Garder que les colonnes utiles
    list_column = [column for column in df_tianda_stock.columns if not 'Q' in str(column)]
    df_tianda_stock = df_tianda_stock[list_column]

    df_tianda_stock = df_tianda_stock[2:]

    df_tianda_stock = df_tianda_stock[df_tianda_stock.columns[2:]]

    # Filtrer les lignes inutililes (nulle)
    df_tianda_stock = df_tianda_stock[~df_tianda_stock['product_type'].isnull()]

    # Get df for the value of stock
    df_tianda_value_stock = df_tianda_stock[df_tianda_stock['product_type'].isin(['Value - Billet', 'Value - WIP/FG'])]

    # Filtrer les lignes qui ne concerne pas le type d'un produit
    df_tianda_stock = df_tianda_stock[
        df_tianda_stock['product_type'].isin(utils.get_list_product_type_impala(v_ibis_client))]

    # melt le dataframes (row to column)
    df_tianda_stock = df_tianda_stock.melt(id_vars=["product_type"], var_name="sprint_date", value_name="qty")

    df_tianda_stock['qty'] = df_tianda_stock['qty'].fillna(0)
    # TODO a décommenter
    # df_tianda_stock = df_tianda_stock[df_tianda_stock['sprint_date'] < datetime.now().strftime('%m.%Y')]

    df_tianda_stock['qty'] = df_tianda_stock['qty'].astype(float)

    # somme des stocks par product type
    df_tianda_stock = df_tianda_stock.groupby(["product_type", "sprint_date"]).agg('sum').reset_index()

    df_tianda_value_stock = df_tianda_value_stock.melt(id_vars=["product_type"], var_name="sprint_date",
                                                       value_name="value")

    df_tianda_value_stock_billet = df_tianda_value_stock[df_tianda_value_stock['product_type'] == 'Value - Billet']
    df_tianda_value_stock_billet['product_type'] = '3 - Billet'
    df_tianda_stock = df_tianda_stock.merge(right=df_tianda_value_stock_billet, how='left',
                                            on=["sprint_date", 'product_type'])

    df_tianda_value_stock_WIP = df_tianda_value_stock[df_tianda_value_stock['product_type'] == 'Value - WIP/FG']
    df_tianda_value_stock_WIP['product_type'] = '4 - WIP'
    df_tianda_stock = df_tianda_stock.merge(right=df_tianda_value_stock_WIP, how='left',
                                            on=["sprint_date", 'product_type'])

    df_tianda_value_stock_FP = df_tianda_value_stock[df_tianda_value_stock['product_type'] == 'Value - WIP/FG']
    df_tianda_value_stock_FP['product_type'] = '5 - Finished goods'
    df_tianda_stock = df_tianda_stock.merge(right=df_tianda_value_stock_FP, how='left',
                                            on=["sprint_date", 'product_type'])

    def concat_value(raw):
        if not pd.isnull(raw['value']):
            return raw['value']
        elif not pd.isnull(raw['value_y']):
            return raw['value_y']
        elif not pd.isnull(raw['value_x']):
            return raw['value_x']

    df_tianda_stock['value'] = df_tianda_stock.apply(lambda raw: concat_value(raw), axis=1)

    df_tianda_stock = df_tianda_stock.drop(columns=['value_y', 'value_x'])

    # add last columns
    df_tianda_stock['company'] = 'Tianda'
    df_tianda_stock['currency'] = 'CNY'

    # get sprint date table
    df_sprint_dates = utils.get_sprint_dates()

    df_sprint_dates['sprint_date_join'] = df_sprint_dates['sprint_date'].apply(
        lambda x: datetime.strptime(str(x), "%d/%m/%Y").strftime("%m.%Y"))

    df_tianda_stock = df_tianda_stock.merge(right=df_sprint_dates, how='left', left_on='sprint_date',
                                            right_on='sprint_date_join')

    df_tianda_stock = df_tianda_stock.drop(columns=['sprint_date_x', 'sprint_date_join']) \
        .rename(columns={'sprint_date_y': 'sprint_date', 'value': 'amount'})

    df_tianda_stock = df_tianda_stock[['period', 'sprint_date', 'company', 'product_type', 'qty', 'amount', 'currency']]

    df_tianda_stock['qty'] = df_tianda_stock['qty'] * 1000

    df_tianda_stock['amount'] = df_tianda_stock['amount'] * df_tianda_stock['qty']

    df_tianda_stock = df_tianda_stock[df_tianda_stock['period'] == df_tianda_stock['period']]

    return df_tianda_stock


def treat_vstar_excel_file(excel_file_path):
    # Lire le fichier excel pour extraire les dates
    df_date = pd.read_excel(excel_file_path, sheet_name=0, skiprows=0)[0:2].reset_index(drop=True)
    df_date = df_date.drop(columns=[df_date.columns[0], df_date.columns[1]])

    df_date = df_date.T.reset_index(drop=True)
    df_date[0] = df_date[0].apply(lambda x: str(x)[2:])
    df_date["date"] = df_date[1].astype(str) + " " + df_date[0].astype(str)

    list_column_header = ['Product Type', 'Ref']
    list_column_header = list_column_header + list(df_date["date"])[:-1] + ["Jan 22"]
    list_column_header = [x for x in list_column_header if x not in ['Source n', 'Unit n', 'Product Type n', 'Ref n']]

    # Lecture du fichier excel et suppression des colonnes inutiles
    df = pd.read_excel(excel_file_path, sheet_name=0, skiprows=2)
    df = df.drop(columns=[df.columns[0], df.columns[1], df.columns[2], df.columns[3]])

    # renommer les colonnes avec les dates
    df.columns = list_column_header

    # passer des mois en colonnes en ligne (melt the dataframe)
    df = df.melt(id_vars=["Product Type", "Ref"], var_name="Period", value_name="Value")

    # garder les valuers qui nous intérresse
    df = df[(df['Ref'].isin(['Quantity', 'Value', 'Flow'])) & (~df['Product Type'].isnull())]

    # Replace null values and characters for aggregation
    df = df.fillna(0)
    df['Value'] = df['Value'].apply(lambda x: 0 if '-' in str(x) else x)

    # aggréger les données avec la fonction somme sur les valeurs
    df = df.groupby(["Product Type", "Ref", 'Period']).agg('sum').reset_index()

    # passer les valeurs de type de produit en colonnes
    df = df.pivot_table('Value', ['Product Type', 'Period'], 'Ref').reset_index()

    # formater la période en mmm yy (ex: janv 19)
    # df['Period'] = df['Period'] + ' ' + str(year)[2:]

    # Ajouter la company
    df['company'] = 'VSTAR'

    # Ajouter la Currency
    df['currency'] = 'USD'

    # Renommer les colonnes
    df = df.rename(columns={'Quantity': 'qty', 'Value': 'amount', 'Product Type': 'product_type', 'Period': 'period'})
    df.columns = map(str.lower, df.columns)

    # get sprint date table
    df_sprint_dates = utils.get_sprint_dates()

    # merge sprint date with df stock
    df = df.merge(right=df_sprint_dates, how='left', on='period')

    df = df[['period', 'sprint_date', 'company', 'product_type', 'qty', 'amount', 'currency']]

    return df


def get_vsb_reference_tab(hdfs_path_raw, site_name, v_client_hdfs):
    def normalized_product_type(cell):
        if cell == 'Billets':
            return '3 - Billet'
        elif cell == 'Semi-Finished':
            return '4 - WIP'
        elif cell == 'Finished':
            return '5 - Finished goods'

    list_files_vsb = v_client_hdfs.list(hdfs_path_raw + site_name)
    list_month = []
    list_file = []
    list_year = []
    df_files = pd.DataFrame()

    # identifier le fichier le plus récent
    for file in list_files_vsb:
        try:
            list_year.append(int(file.split('.')[0][-6:-2]))
            list_month.append(int(file.split('.')[0][-2:]))
            list_file.append(file)
        except ValueError:
            pass

    df_files['files'] = list_file
    df_files['months_nb'] = list_month
    df_files['year'] = list_year

    if len(df_files[(df_files['year'] == datetime.now().year)]) == 0:
        nameFile = \
        df_files[(df_files['year'] == datetime.now().year - 1) & (df_files['months_nb'] == max(df_files['months_nb']))][
            'files'].iloc[0]
    else:
        nameFile = \
        df_files[(df_files['year'] == datetime.now().year) & (df_files['months_nb'] == max(df_files['months_nb']))][
            'files'].iloc[0]

    v_client_hdfs.download(hdfs_path_raw + site_name + '/' + nameFile, '.', overwrite=True, n_threads=1, temp_dir=None)

    # Lire le fichier qui le plus récent. Qui a le mois le plus élevé de l'année en cours
    df_reference = pd.read_excel(nameFile, sheet_name='10_Stock_Point_Id')

    df_reference['Type of product'] = df_reference['Type of product'].apply(lambda x: normalized_product_type(x))

    return df_reference


def treat_vsb_files(v_hdfs_path_histo, v_hdfs_path_raw, v_hdfs_path_error, v_site_name, v_client_hdfs, v_logger):
    list_files_vsb = v_client_hdfs.list(v_hdfs_path_raw + v_site_name)
    if not list_files_vsb:
        raise NameError('There is no VSB file')

    df_reference_product_type_vsb = get_vsb_reference_tab(v_hdfs_path_raw, v_site_name, v_client_hdfs)

    df_inventory_vsb = pd.DataFrame()
    for my_file in list_files_vsb:
        utils.download_file_from_hdfs(v_hdfs_path_raw, v_site_name + '/' + my_file, v_client_hdfs)
        v_logger.info('Treating file: ' + my_file)

        if my_file.startswith('Dynamic_'):
            df_inventory_vsb = df_inventory_vsb.append(pd.read_excel(my_file, sheet_name='6_Stock_Extract', skiprows=1))

        elif my_file.startswith('VSB raw material'):
            """
            df_flow_vsb_raw_mat = pd.read_excel(my_file, sheet_name='VSB RM flow', skiprows=2)
            df_flow_vsb_raw_mat['date_tmp'] = df_flow_vsb_raw_mat['Date'].apply(lambda x: \
                                    datetime.strptime(x, "%B %Y").strftime("%b %y"))
            df_flow_vsb_raw_mat['company'] = 'VSB'

            df_sprint_dates = utils.get_sprint_dates()

            df_flow_vsb_raw_mat = df_flow_vsb_raw_mat.merge(right=df_sprint_dates, how='left', left_on='date_tmp',
                                                            right_on='period')
            """

            df_inventory_vsb_raw_mat = pd.read_excel(my_file, sheet_name='VSB RM Inv', skiprows=2)
            df_inventory_vsb_raw_mat['date_tmp'] = df_inventory_vsb_raw_mat['Date'].apply(lambda x: \
                                                                                              datetime.strptime(x,
                                                                                                                "%B %Y").strftime(
                                                                                                  "%b %y"))
            df_inventory_vsb_raw_mat['company'] = 'VSB'

            df_sprint_dates = utils.get_sprint_dates()
            df_inventory_vsb_raw_mat = df_inventory_vsb_raw_mat.merge(right=df_sprint_dates, how='left',
                                                                      left_on='date_tmp',
                                                                      right_on='period')

            # Quantity (tons)	Value (R$)
            df_inventory_vsb_raw_mat = df_inventory_vsb_raw_mat.rename(columns={'Type': 'product_type', \
                                                                                'Quantity (tons)': 'qty', \
                                                                                'Value (R$)': 'amount', \
                                                                                'Currency': 'currency'})
            df_inventory_vsb_raw_mat = df_inventory_vsb_raw_mat[['period', 'sprint_date', 'company', 'product_type', \
                                                                 'qty', 'amount', 'currency']]
            df_inventory_vsb_raw_mat = df_inventory_vsb_raw_mat[~df_inventory_vsb_raw_mat['qty'].isnull()]

            df_inventory_vsb_raw_mat['currency'] = 'BRL'

        else:
            error_message = 'PRI | File name is not correct. Should start with "Dynamic_" or "VSB raw material": ' + my_file
            v_logger.error(error_message)
            utils.push_flag(v_hdfs_path_error, 'invalidate_flow_vsb_flag_error', v_client_hdfs, error_message)

    df_inventory_vsb = df_inventory_vsb.rename(columns={'Date': 'sprint_date', 1: 'year', 2: 'week_no', 3: 'Site', \
                                                        'Point of stock in the VSM': 'Stock Point name', \
                                                        5: 'flow_next_month'})

    df_inventory_vsb = df_inventory_vsb.merge(right=df_reference_product_type_vsb, how='left', on=['Stock Point name'])

    df_inventory_vsb['company'] = 'VSB'
    df_inventory_vsb['currency'] = 'BRL'

    df_sprint_dates = utils.get_sprint_dates()
    df_sprint_dates['sprint_date_new'] = df_sprint_dates['sprint_date'].apply(lambda x: x[-7:])

    df_inventory_vsb['sprint_date_new'] = df_inventory_vsb['sprint_date'].apply(
        lambda x: datetime.strptime(str(x), '%Y-%m-%d %H:%M:%S').strftime('%m/%Y'))

    df_inventory_vsb = df_inventory_vsb.merge(right=df_sprint_dates, how='left', on='sprint_date_new')

    df_inventory_vsb = df_inventory_vsb.rename(columns={'sprint_date_y': 'sprint_date'})

    df_inventory_vsb = df_inventory_vsb.rename(columns={'Type of product': 'product_type', 'Quantity_tons': 'qty', \
                                                        'Quantity_KR$': 'amount'})

    df_inventory_vsb = pd.concat([df_inventory_vsb, df_inventory_vsb_raw_mat], ignore_index=True)
    # , 'amount'
    df_inventory_vsb = df_inventory_vsb.groupby(["product_type", "sprint_date", 'company', 'period', 'currency']).agg(
        'sum').reset_index()

    df_inventory_vsb = df_inventory_vsb[
        ['period', 'sprint_date', 'company', 'product_type', 'qty', 'amount', 'currency']]

    def vsb_multiply(row):
        if row['product_type'] in ['3 - Billet', '4 - WIP', '5 - Finished goods']:
            return row['amount'] * 1000
        else:
            return row['amount']

    df_inventory_vsb['amount'] = df_inventory_vsb.apply(lambda row: vsb_multiply(row), axis=1)

    columns_order = list(df_inventory_vsb.columns)
    df_inventory_vsb = df_inventory_vsb.groupby(['period', 'sprint_date', 'company', 'product_type', 'currency']) \
        .sum().reset_index()
    df_inventory_vsb = df_inventory_vsb[columns_order]

    for my_file in list_files_vsb:
        utils.inventory_log_file(v_hdfs_path_raw, v_hdfs_path_histo, my_file, v_site_name, v_client_hdfs)

    return df_inventory_vsb


def treat_controlling(v_hdfs_path_histo, v_hdfs_path_raw, v_site_name, v_client_hdfs, v_logger):
    list_files = v_client_hdfs.list(v_hdfs_path_raw + v_site_name)
    if not list_files:
        raise NameError('There is no Controlling file')

    df_inventory = pd.DataFrame()
    for file in list_files:
        utils.download_file_from_hdfs(v_hdfs_path_raw, v_site_name + '/' + file, v_client_hdfs)
        v_logger.info('Treating file: ' + file)

        df_inventory_tmp = pd.read_excel(file, skiprows=13)
        df_inventory_tmp = df_inventory_tmp.drop(columns='Unnamed: 0').rename(columns={'Unnamed: 1': 'product_type'})
        df_inventory_tmp = df_inventory_tmp[
            (df_inventory_tmp['product_type'].str.lower().str.contains('other consumables')) | \
            (df_inventory_tmp['product_type'].str.lower().str.contains('total'))]

        df_inventory_tmp = df_inventory_tmp.melt(id_vars='product_type', var_name='site', value_name='amount')

        df_inventory_tmp_other_consumables = df_inventory_tmp[
            df_inventory_tmp['product_type'].str.lower().str.contains('other consumables')]
        df_inventory_tmp_total = df_inventory_tmp[df_inventory_tmp['product_type'].str.lower().str.contains('total')]

        df_inventory_tmp = pd.merge(left=df_inventory_tmp_other_consumables, right=df_inventory_tmp_total, on='site' \
                                    , suffixes=['_cons', '_total'])

        period = file[0:4]
        df_inventory_tmp['period'] = period

        df_inventory = df_inventory.append(df_inventory_tmp)

    # Traiter les fichiers
    df_inventory['amount'] = df_inventory['amount_total'] - df_inventory['amount_cons']
    df_inventory['amount'] = df_inventory['amount'] * 1000000

    df_inventory['currency'] = 'EUR'

    def clean_site(x):
        if 'lheim' in x.lower():
            return 'Mulheim'
        elif 'tianda' in x.lower():
            return 'Tianda'
        elif 'rath ' in x.lower():
            return 'Rath Plug'
        elif 'vsb ' in x.lower():
            return 'VSB'
        elif 'vmogfr ' in x.lower():
            return 'VOGFR'
        elif 'vmstar ' in x.lower():
            return 'VSTAR'
        else:
            return x + ': unrecognized site'

    df_inventory['site'] = df_inventory['site'].apply(lambda x: clean_site(x))

    df_inventory['period'] = df_inventory['period'].apply(lambda x: datetime.strptime(x, '%m%y').strftime('%b %y'))

    df_sprint_dates = utils.get_sprint_dates()
    df_inventory = df_inventory.merge(right=df_sprint_dates, how='left', on='period')

    df_inventory = df_inventory[['sprint_date', 'period', 'site', 'amount', 'currency']]

    for file in list_files:
        utils.inventory_log_file(v_hdfs_path_raw, v_hdfs_path_histo, file, v_site_name, v_client_hdfs)

    return df_inventory


# MAIN
# noinspection PyInterpreter
try:
    # déclaration du logger
    # create logger
    logger = logging.getLogger('PRI | Treat Flow Data')
    logger.setLevel(logging.DEBUG)

    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(filename)s (line: %(lineno)d) - %(name)s - %(message)s',
        datefmt='%d/%m/%Y %H:%M:%S')

    # add formatter to ch
    ch.setFormatter(formatter)

    # add ch to logger
    logger.addHandler(ch)

    logger.info('Starting flow program')

    # déclaration du client HDFS
    logger.info('Initiating HDFS client')
    client_hdfs = utils.return_client_hdfs(os.environ['USER_PRI'])
    # client_hdfs = InsecureClient('http://' + os.environ['IP_HDFS'] + ':' + os.environ['PORT_HDFS'],
    #

    # Downlaod source files from HDFS
    hdfs_path_error = utils.add_backslash(sys.argv[4])
    hdfs_path_raw = utils.add_backslash(sys.argv[1])
    hdfs_path_histo = utils.add_backslash(sys.argv[2])
    hdfs_path_target = utils.add_backslash(sys.argv[3])
    hdfs_path_controlling = utils.add_backslash(sys.argv[5])
    dateFilter = datetime.now().replace(day=1)

    logger.info('hdfs_path_raw: ' + hdfs_path_raw)
    logger.info('hdfs_path_histo: ' + hdfs_path_histo)
    logger.info('hdfs_path_target: ' + hdfs_path_target)
    logger.info('hdfs_path_error: ' + hdfs_path_error)
    logger.info('hdfs_path_controlling: ' + hdfs_path_controlling)
    logger.info('dateFilter: ' + datetime.strftime(dateFilter, '%d/%m/%Y'))

    test_argv = sys.argv[6:len(sys.argv)]

    os.environ['http_proxy'] = ''
    os.environ['https_proxy'] = ''
    logger.info('Initiating Impala Client')
    url_hdfs = utils.get_url_active_namenode(os.environ['USER_PRI_INVALIDATE'])
    url_hdfs = url_hdfs.split(':')[0] + url_hdfs.split(':')[1]
    ibis_hdfs = ibis.hdfs_connect(host=url_hdfs, port=int(os.environ['PORT_HDFS']))
    hdfs_client=ibis_hdfs,
    ibis_client = ibis.impala.connect(host=os.environ['IP_IMPALA'], port=int(os.environ['PORT_IMPALA']),
                                       user=os.environ['USER_PRI_INVALIDATE'],
                                      password=os.environ['USER_PRI_INVALIDATE_PWD'],
                                      auth_mechanism='PLAIN', database=os.environ['IMPALA_BDD_PRI'],
                                      use_ssl=bool(os.environ['IMPALA_SSL_ACTIVATED'] == "1"))

except:
    error_message = 'PRI | Error with parameters.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('PRI | Pushing error flag file in: ' + hdfs_path_error + 'inventory_parameters_flag_error')
    utils.push_flag(hdfs_path_error, 'inventory_parameters_flag_error', client_hdfs, error_message)
    sys.exit()

for el in sys.argv[6:len(sys.argv)]:
    try:
        logger.info('Treating file' + hdfs_path_raw + el)
        hdfs_path_file = hdfs_path_raw + el
        site_name = hdfs_path_file.split('/')[len(hdfs_path_file.split('/')) - 2]
        file_name = hdfs_path_file.split('/')[len(hdfs_path_file.split('/')) - 1]
        output_file_name = site_name.split('.')[0] + '_inventory.csv'

        logger.info('hdfs_path_file: ' + hdfs_path_file)
        logger.info('site_name: ' + site_name)
        logger.info('file_name: ' + file_name)
        logger.info('output_file_name: ' + output_file_name)

        if site_name not in ['VSB', 'Controlling']:
            utils.download_file_from_hdfs(hdfs_path_raw, site_name + '/' + file_name, client_hdfs)

        logger.info('treating company: ' + site_name)
        logger.info('treating file: ' + file_name)

        if site_name == 'VOGFR':
            df_inventory_vogfr = treat_vogfr_excel_file(file_name)
            df_inventory_vogfr = utils.filter_df_date(df_inventory_vogfr, 'sprint_date', datetime.now().replace(day=1))
            utils.inventory_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_inventory_vogfr, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'Tianda':
            df_inventory_tianda = treat_tianda_excel_file(file_name, ibis_client)
            print(df_inventory_tianda.head())
            df_inventory_tianda = utils.filter_df_date(df_inventory_tianda, 'sprint_date', datetime.now().replace(day=1))

            # df_inventory_vsb = utils.filter_df_date(df_inventory_vsb, 'sprint_date', datetime.now().replace(day=1))
            utils.inventory_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_inventory_tianda, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'VSB':
            df_inventory_vsb = treat_vsb_files(hdfs_path_histo, hdfs_path_raw, hdfs_path_error, site_name, client_hdfs,
                                               logger)
            df_inventory_vsb = utils.filter_df_date(df_inventory_vsb, 'sprint_date', datetime.now().replace(day=1))
            output_file_name = 'vsb_inventory.csv'
            utils.push_file_hdfs(df_inventory_vsb, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'VSTAR':
            df_inventory_vstar = treat_vstar_excel_file(file_name)
            df_inventory_vstar = utils.filter_df_date(df_inventory_vstar, 'sprint_date', datetime.now().replace(day=1))
            utils.inventory_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_inventory_vstar, hdfs_path_target + output_file_name, client_hdfs)

        elif site_name == 'Mulheim & Rath plug':  # Mulheim or Rath Plug
            logger.info('treating file: ' + file_name + " for Mulheim")
            df_mulheim = treat_rat_mul(file_name, 'Mulheim')
            df_mulheim = utils.filter_df_date(df_mulheim, 'sprint_date', datetime.now().replace(day=1))
            utils.inventory_log_file(hdfs_path_raw, hdfs_path_histo, file_name, site_name, client_hdfs)
            utils.push_file_hdfs(df_mulheim, hdfs_path_target + 'Mulheim_' + output_file_name, client_hdfs)

            logger.info('treating file: ' + file_name + " for Rath Plug")
            df_Rath_Plug = treat_rat_mul(file_name, 'Rath Plug')
            df_Rath_Plug = utils.filter_df_date(df_Rath_Plug, 'sprint_date', datetime.now().replace(day=1))
            utils.push_file_hdfs(df_Rath_Plug, hdfs_path_target + 'Rath_Plug_' + output_file_name, client_hdfs)

        elif site_name == 'Controlling':
            df_inventory_controlling = treat_controlling(hdfs_path_histo, hdfs_path_raw, site_name,
                                                         client_hdfs,
                                                         logger)  # (v_hdfs_path_histo, v_hdfs_path_raw, v_site_name, v_client_hdfs, v_logger):
            df_inventory_controlling = utils.filter_df_date(df_inventory_controlling, 'sprint_date', datetime.now().replace(day=1))
            output_file_name = 'inventory_controlling.csv'
            utils.push_file_hdfs(df_inventory_controlling, hdfs_path_controlling + output_file_name, client_hdfs)

        else:
            raise NameError('site_name is incorrect: ' + site_name)

    except:
        error_message = 'Error while treating : ' + site_name + '\n' + traceback.format_exc()
        logger.error(error_message)
        logger.info('Pushing error flag file in: ' + hdfs_path_error + 'inventory_flag_error_' + site_name)
        utils.push_flag(hdfs_path_error, 'inventory_flag_error_' + site_name, client_hdfs, error_message)
try:
    logger.info("Invalidate Impala Metadata")
    utils.invalidate_impala_metadata()
except:
    error_message = 'Error Invalidate Impala Metadata.' + '\n' + traceback.format_exc()
    logger.error(error_message)
    logger.info('Pushing error flag file in: ' + hdfs_path_error + 'inventory_invalidate_parameters_flag_error')
    utils.push_flag(hdfs_path_error, 'inventory_invalidate_parameters_flag_error', client_hdfs, error_message)